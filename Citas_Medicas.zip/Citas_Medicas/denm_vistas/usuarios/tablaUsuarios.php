<?php 
	
	require_once "../../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();

	$sql="SELECT u.usu_id,
    p.per_ced,
    p.per_apepat,
    p.per_apemat,
    p.per_nom,
    u.usu_correo,
    u.usu_nomlogin,
    u.usu_pass,
    u.usu_estado,
    u.usu_fecha,
    f.Tper_desperfil
   
from tbl_usuario u
inner join tbl_persona p on u.per_id=p.per_id
inner join tbl_tipoperfil f on u.Tper_id=f.Tper_id";
	$result=mysqli_query($conexion,$sql);

 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><center><label>Usuarios Registrados</label></center></caption>
	<tr>
		<td>Persona</td>
		<td>Correo</td>
		<td>Usuario</td>
        <td>Contraseña</td>
        <td>Estado</td>
        <td>Fecha de Registro</td>
        <td>Rol</td>
		<td colspan="2">Acciones</td>
	
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
		<td><?php echo $ver[5]; ?></td>
		<td><?php echo $ver[6]; ?></td>
        <td><?php echo $ver[7]; ?></td>
        <td><?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
        <td><?php echo $ver[10]; ?></td>
		<td>
		<span  data-toggle="modal" data-target="#actualizaUsuarioModal" class="btn btn-warning btn-xs" onclick="agregaDatosUsuario('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminarUsuario('<?php echo $ver[0]; ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>