
<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Historial de Citas Medicas</h1>
			<div class="row">
				<div class="col-sm-4">

                <?php
     include("conexion.php");
     $codigo=$_POST['codigo'];
     mysqli_select_db($conexion,$db)or die("Error al conectar la Base de Datos");
     
     $resgistros=mysqli_query($conexion,"SELECT t.trat_id,
     c.cit_asunto,
     d.cent_nombre,
     concat_ws(' ',c.cit_fecha,c.cit_hora) as fecha,
     c.cit_motivo,
     c.cit_sintomas,
     c.cit_estado,
     c.cit_costo,
     c.cit_estado_pago,
     i.tipo_desc,
     t.trat_medicamento,
     t.trat_nota,
     t.trat_costo,
     t.trat_estado_pago,
     t.trat_estado,
     concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
     concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente,
     r.per_ced
 from tbl_tratamiento t 
 inner join tbl_cita c on t.cit_id=c.cit_id
 inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
 inner join tbl_medico m on c.med_id=m.med_id
 inner join tbl_persona p on m.per_id=p.per_id
 inner join tbl_especialidad e on m.esp_id=e.esp_id
 inner join tbl_paciente a on c.pac_id=a.pac_id
 inner join tbl_persona r on a.per_id=r.per_id
 inner join tbl_centro_medico d on c.cent_id=d.cent_id
 where r.per_ced='$codigo'");
     ?>
     
        <?php
        
        while($registro=mysqli_fetch_array($resgistros)){
        ?>
    <table class="table table-hover table-condensed table-bordered" style="text-align: center;">
    
   
   
	<tr>
		<td>Cita No</td>
		<td>Centro Medico</td>
        <td>Fecha y Hora</td>
        <td>Motivo</td>
        <td>Sintomas</td>
        <td>Estado de Cita</td>
        <td>Costo de Cita</td>
        <td>Estado Pago de Cita</td>
        <td>Tipo de Tratamiento</td>
        <td>Medicamento Recetado</td>
        <td>Nota</td>
        <td>Costo Tratamiento</td>
        <td>Pago Tratamiento</td>
        <td>Estado Tratamiento</td>
        <td>Medico</td>
        <td>Paciente</td>
        
		
	</tr>
    
	<tr>
    <?php
      
        ?>
		<td><?php echo $registro[1]; ?> </td>
		<td><?php echo $registro[2]; ?></td>
	    <td><?php echo $registro[3]; ?></td>
        <td><?php echo $registro[4]; ?></td>
        <td><?php echo $registro[5]; ?></td>
	    <td><?php echo $registro[6]; ?></td>
        <td>$<?php echo $registro[7]; ?></td>
        <td><?php echo $registro[8]; ?></td>
        <td><?php echo $registro[9]; ?></td>
        <td><?php echo $registro[10]; ?></td>
	    <td><?php echo $registro[11]; ?></td>
        <td>$<?php echo $registro[12]; ?></td>
        <td><?php echo $registro[13]; ?></td>
        <td><?php echo $registro[14]; ?></td>
        <td><?php echo $registro[15]; ?></td>
        <td><?php echo $registro[16]; ?></td>
        
	</tr>
    </table>           
    <?php 
       
                 
   }
        ?>    
                
            
				</div>
				
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		
       
	</body>
    </html>
	
    <script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>