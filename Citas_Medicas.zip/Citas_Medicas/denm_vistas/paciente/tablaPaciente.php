<?php 
	require_once "../../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="SELECT p.pac_id,
    r.per_ced,
    r.per_apepat,
    r.per_apemat,
    r.per_nom,
    p.pac_enfermedad,
    p.pac_alergias,
    p.pac_medicamento,
    p.pac_estado
from tbl_paciente p 
inner join tbl_persona r on p.per_id=r.per_id
where p.pac_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>

<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Pacientes</label></caption>
	<tr>
		<td>Persona</td>
		<td>Enfermedades</td>
		<td>Alergias</td>
        <td>Medicamentos</td>
        <td>Estado</td>
		<td colspan="2">Acciones</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
		<td><?php echo $ver[5]; ?></td>
		<td><?php echo $ver[6]; ?></td>
		<td><?php echo $ver[7]; ?></td>
		<td><?php echo $ver[8]; ?></td>
		<td>
			<span  data-toggle="modal" data-target="#abremodalPac" class="btn btn-warning btn-xs" onclick="agregaDatosPac('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaPac('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>