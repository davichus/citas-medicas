<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Especialidades Medicas</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmEsp">
						<label>Especialidad</label>
						<input type="text" class="form-control input-sm" name="txt_esp" id="txt_esp" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                       
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaEsp" name="btnAgregaEsp">Registrar Especialidad</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaEspecialidadLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaEsp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Especialidad</h4>
					</div>
					<div class="modal-body">
						<form id="frmEspU">
							<input type="text" hidden="" id="ide" name="ide">
							<label>Especialidad Medica</label>
							<input type="text" id="esp" name="esp" class="form-control input-sm" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						</form>


					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaEsp" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaEspecialidadLoad').load("especialidad/tablaEspecialidad.php");

			$('#btnAgregaEsp').click(function(){

				vacios=validarFormVacio('frmEsp');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmEsp').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/especialidad/agregaEsp.php",
					success:function(r){
						if(r==2){
							$('#tablaEspecialidadLoad').load("especialidad/tablaEspecialidad.php");
								alertify.alert("Esta Especialidad ya ha sido registrada, prueba con otra!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmEsp')[0].reset();

					$('#tablaEspecialidadLoad').load("especialidad/tablaEspecialidad.php");
					alertify.success("Especialidad agregada con exito!!");
				}else{
					alertify.error("No se pudo agregar Rol");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaEsp').click(function(){

				datos=$('#frmEspU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/especialidad/actualizaEsp.php",
					success:function(r){
						if(r==1){
							$('#tablaEspecialidadLoad').load("especialidad/tablaEspecialidad.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(ide,esp){
			$('#ide').val(ide);
			$('#esp').val(esp);
		}

		function eliminaEsp(ide){
			alertify.confirm('¿Desea eliminar esta Especialidad?', function(){ 
				$.ajax({
					type:"POST",
					data:"ide=" + ide,
					url:"../denm_procesos/especialidad/eliminaEsp.php",
					success:function(r){
						if(r==1){
							$('#tablaEspecialidadLoad').load("especialidad/tablaEspecialidad.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>