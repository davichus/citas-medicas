<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denn_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro de Paciente</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmPac">
                    <label>Persona</label>
                            <select class="form-control input-sm" id="sl_persona" name="sl_persona">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT per_id,
				per_ced,per_apepat,per_apemat,per_nom
				from tbl_persona";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
            </select>
                      
						<label>Enfermedad</label>
						<textarea  id="txt_enf" name="txt_enf" class="form-control input-sm"></textarea>
						<label>Alergias</label>
						<textarea  id="txt_ale" name="txt_ale" class="form-control input-sm"></textarea>
						<label>Medicamentos</label>
						<textarea  id="txt_med" name="txt_med" class="form-control input-sm"></textarea>
						
						<p></p>
						<span class="btn btn-primary" id="btnAgregarPac">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaPacienteLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalPac" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Paciente</h4>
					</div>
					<div class="modal-body">
						<form id="frmPacU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>Persona</label>
                            <select class="form-control input-sm" id="persona" name="persona">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT per_id,
				per_ced,per_apepat,per_apemat,per_nom
				from tbl_persona";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
            </select>
                      
						<label>Enfermedad</label>
						<textarea  id="enf" name="enf" class="form-control input-sm"></textarea>
						<label>Alergias</label>
						<textarea  id="ale" name="ale" class="form-control input-sm"></textarea>
						<label>Medicamentos</label>
						<textarea  id="med" name="med" class="form-control input-sm"></textarea>
						
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPacU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    <script type="text/javascript">
		function agregaDatosPac(id){
			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/paciente/obtenDatosPaciente.php",
				success:function(r){
					
					dato=jQuery.parseJSON(r);
					$('#id').val(dato['pac_id']);
                    $('#persona').val(dato['per_id']);
					$('#enf').val(dato['pac_enfermedad']);
					$('#ale').val(dato['pac_alergias']);
					$('#med').val(dato['pac_medicamento']);
				}
			});
		}

		function eliminaPac(id){
			alertify.confirm('¿Desea eliminar este Paciente?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/paciente/eliminaPaciente.php",
					success:function(r){
						if(r==1){
							$('#tablaPacienteLoad').load("paciente/tablaPaciente.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar :(");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPacU').click(function(){

				datos=$('#frmPacU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/paciente/actualizaPaciente.php",
					success:function(r){
						if(r==1){
							$('#tablaPacienteLoad').load("paciente/tablaPaciente.php");
							alertify.success("Actualizado con exito!!");
						}else{
							alertify.error("Error al actualizar!!");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaPacienteLoad').load("paciente/tablaPaciente.php");

			$('#btnAgregarPac').click(function(){

				vacios=validarFormVacio('frmPac');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				var formData = new FormData(document.getElementById("frmPac"));

				$.ajax({
					url: "../denm_procesos/paciente/insertaPaciente.php",
					type: "post",
					dataType: "html",
					data: formData,
					cache: false,
					contentType: false,
					processData: false,

					success:function(r){
						if(r==2){
							$('#tablaPacienteLoad').load("paciente/tablaPaciente.php");
								alertify.alert("Este Paciente ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r == 1){
							$('#frmPac')[0].reset();
							$('#tablaPacienteLoad').load("paciente/tablaPaciente.php");
							alertify.success("Agregado con exito!!");
						}else{
							alertify.error("fallo al agregar Medico");
						}
					}
				});
				
			});
		});
	</script>
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
    
<?php 
}else{
	header("location:../index.php");
}
?>