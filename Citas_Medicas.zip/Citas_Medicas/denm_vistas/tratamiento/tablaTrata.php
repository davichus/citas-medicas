<?php 
	require_once "../../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="select t.trat_id,
    c.cit_asunto,
    i.tipo_desc,
    t.trat_medicamento,
    t.trat_nota,
    t.trat_costo,
    t.trat_estado_pago,
    t.trat_estado,
    concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
    concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente
from tbl_tratamiento t 
inner join tbl_cita c on t.cit_id=c.cit_id
inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente a on c.pac_id=a.pac_id
inner join tbl_persona r on a.per_id=r.per_id";
	$result=mysqli_query($conexion,$sql);

 ?>

<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Medicos</label></caption>
	<tr>
		<td>Cita No</td>
		<td>Tratamiento</td>
		<td>Medicamento</td>
        <td>Nota</td>
        <td>Costo</td>
        <td colspan="2">Estado Pago</td>
        <td colspan="2">Estado Tratamiento</td>
        <td>Medico</td>
        <td>Paciente</td>
		<td colspan="2">Acciones</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?></td>
        <td><?php echo $ver[5]; ?></td>
        <td><?php
		if($ver[6]=='Anulado'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[6].'</td>';
		}elseif ($ver[6]=='Pendiente'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[6].'</td>';
		}
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[6].'</td>';
		  }
		  
		
		?></td>
        
        
        
        <td><?php
		if($ver[7]=='Cancelado'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[7].'</td>';
		}elseif ($ver[7]=='No Aplico'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[7].'</td>';
		}
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[7].'</td>';
		  }
		  
		
		?></td>
        <td><?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
		<td>
			<span  data-toggle="modal" data-target="#abremodalTrat" class="btn btn-warning btn-xs" onclick="agregaDatosTrat('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaTrat('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>