<?php 
			require_once "../../denn_clases/conexion.php";
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="SELECT Tper_id,Tper_desperfil,Tper_estado 
					FROM tbl_tipoperfil where Tper_estado='A'";
			$result=mysqli_query($conexion,$sql);
	 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Roles</label></caption>
	<tr>
		<td>Rol</td>
		<td>Estado</td>
		<td colspan="2">Aciones</td>
		
	</tr>

	<?php
	while ($ver=mysqli_fetch_row($result)):
	 ?>

	<tr>
		<td><?php echo $ver[1] ?></td>
		<td><?php echo $ver[2] ?></td>
		<td>
			<span class="btn btn-warning btn-xs" data-toggle="modal" data-target="#actualizaRol" onclick="agregaDato('<?php echo $ver[0] ?>','<?php echo $ver[1] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaRol('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>

<?php endwhile; ?>
</table>