<?php

class Conexion{
	static public function conectar()
	{
		$link = new PDO("mysql:host=localhost;dbname=citas_medicas",
						"root",
						"");
		$link->exec("set names utf8");

		return $link;
	}
}

/**
 * 

 */
class ModeloPaises
{
	
	static public function mdlShowPaises(){

		$stmt = Conexion::conectar()->prepare("SELECT * FROM tbl_centro_medico");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}

	static public function mdlTraerDependencias($id_pais){

		$stmt = Conexion::conectar()->prepare("SELECT m.med_id,p.per_ced,per_apepat,per_apemat,
        p.per_nom, e.esp_desc
		FROM tbl_medico m
		inner join tbl_persona p on m.per_id=p.per_id
		inner join tbl_especialidad e on m.esp_id=e.esp_id
		WHERE cent_id = $id_pais");

		$stmt->execute();

		return $stmt->fetchAll();

		$stmt->close();

		$stmt = null;
	}
}



?>