<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denn_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro de Medicos</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmMedico">
                        
                    <label>Persona</label>
						<select class="form-control input-sm" id="sl_persona" name="sl_persona">
							<option value="">--Seleccione--</option>
							<?php while($ver=mysqli_fetch_row($result)): ?>
								<option value="<?php echo $ver[0] ?>"><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></option>
							<?php endwhile; ?>
						</select>
                        <label>Especialidad</label>
			<select class="form-control input-sm" id="sl_esp" name="sl_esp">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT esp_id,
				esp_desc
				from tbl_especialidad";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Horario</label>
			<select class="form-control input-sm" id="sl_hor" name="sl_hor">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT hor_id,
				hor_inicio,hor_fin
				from tbl_horario";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> a <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
			</select>
                        <label>Centro Medico</label>
			<select class="form-control input-sm" id="sl_centro" name="sl_centro">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT cent_id,
				cent_nombre
				from tbl_centro_medico";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
                        
						<p></p>
						<center><span class="btn btn-primary" id="registro">Registrar Medico</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaMedicoLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalMedico" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualiza Medicos</h4>
					</div>
					<div class="modal-body">
						<form id="frmMedicoU">
							<input type="text" hidden="" id="id" name="id">
                            <label>Persona</label>
                            <select class="form-control input-sm" id="persona" name="persona">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT per_id,
				per_ced,per_apepat,per_apemat,per_nom
				from tbl_persona";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
            </select>
                        <label>Especialidad</label>
			<select class="form-control input-sm" id="esp" name="esp">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT esp_id,
				esp_desc
				from tbl_especialidad";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Horario</label>
			<select class="form-control input-sm" id="hor" name="hor">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT hor_id,
				hor_inicio,hor_fin
				from tbl_horario";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> a <?php echo $producto[2] ?></option>
				<?php endwhile; ?>
			</select>
                        <label>Centro Medico</label>
			<select class="form-control input-sm" id="centro" name="centro">
				<option value="A">Selecciona</option>
				<?php
				$sql="SELECT cent_id,
				cent_nombre
				from tbl_centro_medico";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
			</select>
							

						</form>
					</div>
					<div class="modal-footer">
						<button id="btnActualizaMedico" type="button" class="btn btn-warning" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>

	<script type="text/javascript">
		function agregaDatosMedico(id){
			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/medico/obtenDatosMedico.php",
				success:function(r){
					
					dato=jQuery.parseJSON(r);
					$('#id').val(dato['med_id']);
					$('#persona').val(dato['per_id']);
					$('#esp').val(dato['esp_id']);
					$('#hor').val(dato['hor_id']);
					$('#centro').val(dato['cent_id']);
					

				}
			});
		}

		function eliminaMedico(id){
			alertify.confirm('¿Desea eliminar este Medico?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/medico/eliminaMedico.php",
					success:function(r){
						if(r==1){
							$('#tablaMedicoLoad').load("medico/tablaMedico.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar :(");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaMedico').click(function(){

				datos=$('#frmMedicoU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/medico/actualizaMedico.php",
					success:function(r){
						if(r==1){
							$('#tablaMedicoLoad').load("medico/tablaMedico.php");
							alertify.success("Actualizado con exito!!");
						}else{
							alertify.error("Error al actualizar!!");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaMedicoLoad').load("medico/tablaMedico.php");

			$('#registro').click(function(){

				vacios=validarFormVacio('frmMedico');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				var formData = new FormData(document.getElementById("frmMedico"));

				$.ajax({
					url: "../denm_procesos/medico/insertaMedico.php",
					type: "post",
					dataType: "html",
					data: formData,
					cache: false,
					contentType: false,
					processData: false,

					success:function(r){
						if(r==2){
							$('#tablaMedicoLoad').load("medico/tablaMedico.php");
								alertify.alert("Este Medico ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r == 1){
							$('#frmMedico')[0].reset();
							$('#tablaMedicoLoad').load("medico/tablaMedico.php");
							alertify.success("Agregado con exito!!");
						}else{
							alertify.error("fallo al agregar Medico");
						}
					}
				});
				
			});
		});
	</script>
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
	<?php 
}else{
	header("location:../index.php");
}
?>