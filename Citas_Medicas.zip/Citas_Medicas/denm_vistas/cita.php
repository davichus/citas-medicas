<?php include 'db.php'; ?>
<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denn_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Asignacion Cita Medica</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmCita">
                    
                    <label>Asunto</label>
							<input type="text" class="form-control input-sm" id="txt_asunto" name="txt_asunto" >
                            <label>Nota</label>
                            <input type="text" class="form-control input-sm" id="txt_nota" name="txt_nota" >
                            <label>Centro Medico</label>
			
							<select class="form-control input-sm" id="sl_centro"  name="sl_centro" onchange="selectpaises()">
          			<option value="">Seleccione Centro Medico</option>
                <?php
                    $paisesdb = ModeloPaises::mdlShowPaises();
                    foreach ($paisesdb as $key => $value) {
                      echo '<option value="'. $value["cent_id"] .'"> '. $value["cent_nombre"] .'</option>';
                    }
                ?>
          			
          		</select>
			
            <label>Medico</label>
			<select class="form-control input-sm" id="sl_medico" name="sl_medico">
          			<option value="">Seleccione un Medico</option>
          		</select>
          
                    <label>Paciente</label>
                            <select class="form-control input-sm" id="sl_paciente" name="sl_paciente">
				<option value="A">Seleccione un Paciente</option>
				<?php
				$sql="select p.pac_id,e.per_ced,e.per_apepat,e.per_apemat,e.per_nom
				from tbl_paciente p
				inner join tbl_persona e on p.per_id=e.per_id";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
            </select>
                      
						<label>Fecha</label>
						<input type="date" class="form-control input-sm" id="txt_fecha" name="txt_fecha" >
						<label>Hora</label>
						<input type="time" class="form-control input-sm" id="txt_hora" name="txt_hora" >
						<label>Motivo</label>
						<textarea  id="txt_motivo" name="txt_motivo" class="form-control input-sm"></textarea>
						<label>Sintomas</label>
						<textarea  id="txt_sintomas" name="txt_sintomas" class="form-control input-sm"></textarea>
						<label>Estado</label>
                            <select class="form-control input-sm" id="sl_estado" name="sl_estado">
				<option value="#">Seleccione un Estado</option>
				<option value="Pendiente">Pendiente</option>
				<option value="Aplicada">Aplicada</option>
				<option value="No Asistio">No Asistio</option>
				<option value="Cancelada">Cancelada</option>
				</select>
				<label>Costo de Cita</label>
						<input type="text" class="form-control input-sm" id="txt_costo" name="txt_costo" >
						<label>Estado Pago</label>
						<select class="form-control input-sm" id="sl_pago" name="sl_pago">
				<option value="#">Seleccione un Estado</option>
				<option value="Pendiente">Pendiente</option>
				<option value="Pagado">Pagado</option>
				<option value="Anulado">Anulado</option>
				
				</select>
						
						<p></p>
						<span class="btn btn-primary" id="btnAgregarCita">Agendar Cita</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaCitaLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalCita" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Cita Medica</h4>
					</div>
					<div class="modal-body">
						<form id="frmCitaU">
                        <input type="text" hidden="" id="id" name="id">
                        <label>Asunto</label>
							<input type="text" class="form-control input-sm" id="asunto" name="asunto" >
                            <label>Nota</label>
                            <input type="text" class="form-control input-sm" id="nota" name="nota" >
                           
          
                    <label>Paciente</label>
                            <select class="form-control input-sm" id="paciente" name="paciente">
				<option value="A">Seleccione un Paciente</option>
				<?php
				$sql="select p.pac_id,e.per_ced,e.per_apepat,e.per_apemat,e.per_nom
				from tbl_paciente p
				inner join tbl_persona e on p.per_id=e.per_id";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?> <?php echo $producto[2] ?> <?php echo $producto[3] ?> <?php echo $producto[4] ?></option>
				<?php endwhile; ?>
            </select>
                      
						<label>Fecha</label>
						<input type="date" class="form-control input-sm" id="fecha" name="fecha" >
						<label>Hora</label>
						<input type="time" class="form-control input-sm" id="hora" name="hora" >
						<label>Motivo</label>
						<textarea  id="motivo" name="motivo" class="form-control input-sm"></textarea>
						<label>Sintomas</label>
						<textarea  id="sintomas" name="sintomas" class="form-control input-sm"></textarea>
						<label>Estado</label>
                            <select class="form-control input-sm" id="estado" name="estado">
				<option value="#">Seleccione un Estado</option>
				<option value="Pendiente">Pendiente</option>
				<option value="Aplicada">Aplicada</option>
				<option value="No Asistio">No Asistio</option>
				<option value="Cancelada">Cancelada</option>
				</select>
				<label>Costo de Cita</label>
				<input type="text" class="form-control input-sm" id="costo" name="costo">
						<label>Estado Pago</label>
						<select class="form-control input-sm" id="pago" name="pago">
				<option value="#">Seleccione un Estado</option>
				<option value="Pendiente">Pendiente</option>
				<option value="Pagado">Pagado</option>
				<option value="Anulado">Anulado</option>
				
				</select>
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarCitaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
	<script src="js.js"></script>
	
	

    <script type="text/javascript">
		function agregaDatosCita(id){
			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/citas/obtenDatosCita.php",
				success:function(r){
					
					dato=jQuery.parseJSON(r);
					$('#id').val(dato['cit_id']);
                    $('#asunto').val(dato['cit_asunto']);
					$('#nota').val(dato['cit_nota']);
					$('#paciente').val(dato['pac_id']);
					$('#fecha').val(dato['cit_fecha']);
					$('#hora').val(dato['cit_hora']);
					$('#motivo').val(dato['cit_motivo']);
					$('#sintomas').val(dato['cit_sintomas']);
					$('#estado').val(dato['cit_estado']);
					$('#costo').val(dato['cit_costo']);
					$('#pago').val(dato['cit_estado_pago']);

				}
			});
		}

		function eliminaCita(id){
			alertify.confirm('¿Desea seguro que desea cancelar la Cita Medica?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/citas/eliminaCita.php",
					success:function(r){
						if(r==1){
							$('#tablaCitaLoad').load("cita/tablaCita.php");
							alertify.success("Cita Cancelada!!");
						}else{
							alertify.error("No se pudo cancelar");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarCitaU').click(function(){

				datos=$('#frmCitaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/citas/actualizaCita.php",
					success:function(r){
						if(r==1){
							$('#tablaCitaLoad').load("cita/tablaCita.php");
							alertify.success("Actualizado con exito!!");
						}else{
							alertify.error("Error al actualizar!!");
						}
					}
				});
			});
		});
	</script>

	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaCitaLoad').load("cita/tablaCita.php");

			$('#btnAgregarCita').click(function(){

				vacios=validarFormVacio('frmCita');
               
				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				var formData = new FormData(document.getElementById("frmCita"));

				$.ajax({
					url: "../denm_procesos/citas/agregaCita.php",
					type: "post",
					dataType: "html",
					data: formData,
					cache: false,
					contentType: false,
					processData: false,

					success:function(r){
						if(r==2){
							$('#tablaCitaLoad').load("cita/tablaCita.php");
								alertify.alert("Esta Cita ya ha sido registrada, prueba con otro!!");
							}
						
						else if(r == 1){
							$('#frmCita')[0].reset();
							$('#tablaCitaLoad').load("cita/tablaCita.php");
							alertify.success("Agregado con exito!!");
						}else{
							alertify.error("fallo al agregar Medico");
						}
					}
				});
				
			});
		});
	</script>
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
    
<?php 
}else{
	header("location:../index.php");
}
?>