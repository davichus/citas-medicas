<?php 
session_start();
if(isset($_SESSION['usuario'])){

    ?>
    
<!DOCTYPE html>
	<html>
	<head>
		<title>Personas</title>
        <?php require_once "menu.php"; ?>
        
    <?php 
	require_once "../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="SELECT c.cit_id,
    c.cit_asunto,
    c.cit_nota,
    t.cent_nombre,
    concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom, e.esp_desc) as medico,
     concat_ws(' ', o.per_ced, o.per_apepat,o.per_apemat,o.per_nom) as paciente,
     c.cit_fecha,
     c.cit_hora,
     c.cit_motivo,
     c.cit_sintomas,
     c.cit_estado,
     c.cit_costo,
     c.cit_estado_pago
FROM tbl_cita c
inner join tbl_centro_medico t on c.cent_id=t.cent_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente i on c.pac_id=i.pac_id
inner join tbl_persona o on i.per_id=o.per_id
where c.cit_estado='aplicada'";
	$result=mysqli_query($conexion,$sql);

 ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Citas Medicas Atendidas</h1>
			<div class="row">
				<div class="col-sm-4">
					<form  method="POST" action="">
                    <table class="table table-hover table-condensed table-bordered" style="text-align: center;" id="table"> 
	<caption><label>Citas Medicas</label></caption>
	<tr>
		<td>Asunto</td>
		<td>Nota</td>
		<td>Centro Medico</td>
        <td>Medico</td>
        <td>Paciente</td>
        <td>Fecha y Hora</td>
        <td>Motivo</td>
        <td>Sintomas</td>
        <td colspan="2">Estado</td>
        <td>Costo</td>
		<td colspan="2">Estado Pago</td>
		
		<td colspan="">Factura</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?></td>
        <td><?php echo $ver[5]; ?></td>
        <td><?php echo $ver[6]; ?> <?php echo $ver[7]; ?></td>
		<td><?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
		
		
		<td>
		<?php
		if($ver[10]=='Cancelada'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[10].'</td>';
		}elseif ($ver[10]=='Pendiente'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[10].'</td>';
		}elseif ($ver[10]=='No Asistio'){
			echo '<td class="btn btn-primary">'.$ver[10].'</td>';
		}
		
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[10].'</td>';
		  }
		  
		
		?>
		
	
	</td>
		
		
		
		<td class="">$<?php echo $ver[11]; ?></td>
		<td><?php
		if($ver[12]=='Anulado'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[12].'</td>';
		}elseif ($ver[12]=='Pendiente'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[12].'</td>';
		}
		
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[12].'</td>';
		  }
		  
		
		?></td>
		<td>
						<a href="../denm_procesos/citas/crearReportePdf.php?cit_id=<?php echo $ver[0] ?>" class="btn btn-danger btn-xs">
							Imprimir <span class="glyphicon glyphicon-file"></span>
						</a>	
					</td>
	</tr>
<?php endwhile; ?>
</table>
						
					</form>
				</div>
				
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		
       
	</body>
    </html>
	
    <script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>