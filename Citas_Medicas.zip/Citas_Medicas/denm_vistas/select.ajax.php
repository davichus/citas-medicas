<?php
include 'db.php';
$id = $_POST["id"];

$estadosdb = ModeloPaises::mdlTraerDependencias($id);

foreach ($estadosdb as $key => $value) {
	echo '<option value="'.$value["med_id"].'">'.$value["per_ced"].' '.$value["per_apepat"].' '.$value["per_apemat"].' '.$value["per_nom"].' '.$value["esp_desc"].'
	
	
	
	</option>';
}