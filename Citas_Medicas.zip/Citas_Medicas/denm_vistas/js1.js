function selectpaises() {
	var id_pais = $("#centro").val();
	$.ajax({
		url: "select.ajax.php",
		method: "POST",
		data: {
			"id":id_pais
		},
		success: function(respuesta){
			$("#medico").attr("disabled", false);
			$("#medico").html(respuesta);
		}
	})
}