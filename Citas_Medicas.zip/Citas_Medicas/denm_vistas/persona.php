<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Personas</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Datos Personales</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmPersona">
					    <label>Cedula</label>
						<input type="text" class="form-control input-sm" id="txt_cedula" name="txt_cedula" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Apellido Paterno</label>
						<input type="text" class="form-control input-sm" id="txt_apepat" name="txt_apepat" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Apellido Materno</label>
						<input type="text" class="form-control input-sm" id="txt_apemat" name="txt_apemat" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Nombres</label>
						<input type="text" class="form-control input-sm" id="txt_nom" name="txt_nom" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        <label>Genero</label>
							<br>
							<select name="sl_genero" class="form-control input-sm" id="sl_genero" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="M">Masculino</option>
                          <option value="F">Femenino</option>
                       
                          </select>
                        
                        
                        <label>Fecha Nacimiento</label>
						<input type="date" class="form-control input-sm" id="txt_fecha" name="txt_fecha">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="txt_telf" name="txt_telf" onkeypress="return Validletra(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
						<label>Direccion</label>
						<input type="text" class="form-control input-sm" id="txt_dir" name="txt_dir">
						<p></p>
						<span class="btn btn-primary" id="btnAgregarPersona">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaPersonaLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalPersonaUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Datos Personales</h4>
					</div>
					<div class="modal-body">
						<form id="frmPersonaU">
                        <input type="text" hidden="" id="idper" name="idper">
						<label>Cedula</label>
							<input type="text" class="form-control input-sm" id="ced" name="ced">
							
							
						<label>Apellido Paterno</label>
						<input type="text" class="form-control input-sm" id="apepat" name="apepat">
						<label>Apellido Materno</label>
						<input type="text" class="form-control input-sm" id="apemat" name="apemat">
						<label>Nombres</label>
						<input type="text" class="form-control input-sm" id="nom" name="nom">
                        <label>Genero</label>
							<br>
							<select name="genero" class="form-control input-sm" id="genero" required>
                          <option value="" disabled selected hidden>--Seleccione--</option>
                          <option value="M">Masculino</option>
                          <option value="F">Femenino</option>
                       
                          </select>
                        
                        
                        <label>Fecha Nacimiento</label>
						<input type="date" class="form-control input-sm" id="fecha" name="fecha">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="telf" name="telf">
						<label>Direccion</label>
						<input type="text" class="form-control input-sm" id="dir" name="dir">
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarPersonaU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaPersonaLoad').load("persona/tablaPersona.php");

			$('#btnAgregarPersona').click(function(){

				vacios=validarFormVacio('frmPersona');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmPersona').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/persona/agregaper.php",
					success:function(r){
						if(r==2){
							$('#tablaPersonaLoad').load("persona/tablaPersona.php");
								alertify.alert("Esta Persona ya ha sido registrada, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmPersona')[0].reset();

					$('#tablaPersonaLoad').load("persona/tablaPersona.php");
					alertify.success("Persona agregada con exito!!");
				}else{
					alertify.error("No se pudo agregar Persona");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarPersonaU').click(function(){

				datos=$('#frmPersonaU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/persona/actualizaPer.php",
					success:function(r){
						if(r==1){
							$('#tablaPersonaLoad').load("persona/tablaPersona.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDatosPersona(idper,ced,apepat,apemat,nom,genero,fecha,telf,dir){
			$('#idper').val(idper);
            $('#ced').val(ced);
            $('#apepat').val(apepat);
            $('#apemat').val(apemat);
            $('#nom').val(nom);
            $('#genero').val(genero);
            $('#fecha').val(fecha);
            $('#telf').val(telf);
            $('#dir').val(dir);
		}

		function eliminarPersona(idper){
			alertify.confirm('¿Desea eliminar este Rol?', function(){ 
				$.ajax({
					type:"POST",
					data:"idper=" + idper,
					url:"../denm_procesos/persona/eliminarPer.php",
					success:function(r){
						if(r==1){
							$('#tablaPersonaLoad').load("persona/tablaPersona.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>