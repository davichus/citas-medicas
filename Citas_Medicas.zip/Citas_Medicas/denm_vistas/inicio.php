<?php 
	session_start();
	if(isset($_SESSION['usuario'])){
		
 ?>
<!DOCTYPE html>
<html>
<head>
	<title>Inicio</title>
	<?php require_once "menu.php"; ?>
	<?php require_once "../denn_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
</head>
<body>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
<div class="panel panel-container">
			<div class="row">
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-teal panel-widget border-right">
						<div class="row no-padding">
						<em class="fa fa-xl "><img src="imagenes/hospital.png" class="img-responsive">
						</em>
						
							<?php
				$sql="SELECT count(*)As total
				FROM tbl_centro_medico";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Hospitales</div>
						
						
						
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-blue panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/doctor.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_medico";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Medicos</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-orange panel-widget border-right">
						<div class="row no-padding"><em class="fa fa-xl fa">

						<img src="imagenes/paciente.png" class="img-responsive">
						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_paciente";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Pacientes</div>
						</div>
					</div>
				</div>
				<div class="col-xs-6 col-md-3 col-lg-3 no-padding">
					<div class="panel panel-red panel-widget ">
						<div class="row no-padding"><em class="fa fa-xl fa">
						<img src="imagenes/cita.png" class="img-responsive">

						</em>
						<?php
				$sql="SELECT count(*)As total
				FROM tbl_cita";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					
							<div class="large"><?php echo $producto[0] ?></div>

							<?php endwhile; ?>

							<div class="text-muted">Citas Medicas</div>
						
						
						
						
						</div>
					</div>
				</div>
			</div><!--/.row-->
		</div>
		</div>
</body>
</html>
<?php 
	}else{
		header("location:../index.php");
	}
 ?>