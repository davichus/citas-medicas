<?php 
session_start();
if(isset($_SESSION['usuario'])){

    ?>
    
<!DOCTYPE html>
	<html>
	<head>
		<title>Personas</title>
        <?php require_once "menu.php"; ?>
        
    <?php 
	require_once "../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="select t.trat_id,
    c.cit_asunto,
    i.tipo_desc,
    t.trat_medicamento,
    t.trat_nota,
    t.trat_costo,
    t.trat_estado_pago,
    t.trat_estado,
    concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
    concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente
from tbl_tratamiento t 
inner join tbl_cita c on t.cit_id=c.cit_id
inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente a on c.pac_id=a.pac_id
inner join tbl_persona r on a.per_id=r.per_id
where t.trat_estado='Aplicado'";
	$result=mysqli_query($conexion,$sql);

 ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Citas Medicas Atendidas</h1>
			<div class="row">
				<div class="col-sm-4">
					<form  method="POST" action="">
                    <table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Medicos</label></caption>
	<tr>
		<td>Cita No</td>
		<td>Tratamiento</td>
		<td>Medicamento</td>
        <td>Nota</td>
        <td>Costo</td>
        <td colspan="2">Estado Pago</td>
        <td colspan="2">Estado Tratamiento</td>
        <td>Medico</td>
        <td>Paciente</td>
		<td>Acciones</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?></td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?></td>
        <td><?php echo $ver[5]; ?></td>
        <td><?php
		if($ver[6]=='Anulado'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[6].'</td>';
		}elseif ($ver[6]=='Pendiente'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[6].'</td>';
		}
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[6].'</td>';
		  }
		  
		
		?></td>
        
        
        
        <td><?php
		if($ver[7]=='Cancelado'){
			echo '<td class="btn btn-danger btn-xs">'.$ver[7].'</td>';
		}elseif ($ver[7]=='No Aplico'){
			echo '<td class="btn btn-warning btn-xs">'.$ver[7].'</td>';
		}
		
		else{
			echo '<td class="btn btn-success btn-xs">'.$ver[7].'</td>';
		  }
		  
		
		?></td>
        <td><?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
		<td>
        <a href="../denm_procesos/tratamiento/crearReportePdf.php?trat_id=<?php echo $ver[0] ?>" class="btn btn-danger btn-xs">
							Imprimir <span class="glyphicon glyphicon-file"></span>
						</a>	
		</td>
        
	</tr>
<?php endwhile; ?>
</table>
						
					</form>
				</div>
				
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		
       
	</body>
    </html>
	
    <script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>