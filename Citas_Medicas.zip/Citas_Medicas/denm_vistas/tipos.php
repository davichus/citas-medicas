<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Administrar Tratamientos</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmTipo">
						<label>Nombre Tratamiento</label>
						<input type="text" class="form-control input-sm" name="txt_nom" id="txt_nom" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                       
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaTipo" name="btnAgregaTipo">Registrar Tratamiento</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaTipoLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaTipo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Tipo Tratamiento</h4>
					</div>
					<div class="modal-body">
						<form id="frmTipoU">
							<input type="text" hidden="" id="id" name="id">
							<label>Nombre Tratamiento</label>
							<input type="text" id="nom" name="nom" class="form-control input-sm">
						</form>


					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaTipo" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaTipoLoad').load("tipo/tablaTipo.php");

			$('#btnAgregaTipo').click(function(){

				vacios=validarFormVacio('frmTipo');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmTipo').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/tipo/agregaTipo.php",
					success:function(r){
						if(r==2){
							$('#tablaTipoLoad').load("tipo/tablaTipo.php");
								alertify.alert("Este Tipo de Tratamiento ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmTipo')[0].reset();

					$('#tablaTipoLoad').load("tipo/tablaTipo.php");
					alertify.success("Tratamiento agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar Tratamiento");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaTipo').click(function(){

				datos=$('#frmTipoU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/tipo/actualizaTipo.php",
					success:function(r){
						if(r==1){
							$('#tablaTipoLoad').load("tipo/tablaTipo.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(id,nom){
			$('#id').val(id);
			$('#nom').val(nom);
		}

		function eliminaTipo(id){
			alertify.confirm('¿Desea eliminar este Tratamiento?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/tipo/eliminarTipo.php",
					success:function(r){
						if(r==1){
							$('#tablaTipoLoad').load("tipo/tablaTipo.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>