<?php 
	require_once "../../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="select t.trat_id,
    c.cit_asunto,
    c.cit_nota,
    d.cent_nombre,
    concat_ws(' ',c.cit_fecha,c.cit_hora) as fecha,
    c.cit_motivo,
    c.cit_sintomas,
    c.cit_estado,
    i.tipo_desc,
    t.trat_medicamento,
    t.trat_nota,
    t.trat_estado,
    concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
    concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente
from tbl_tratamiento t 
inner join tbl_cita c on t.cit_id=c.cit_id
inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente a on c.pac_id=a.pac_id
inner join tbl_persona r on a.per_id=r.per_id
inner join tbl_centro_medico d on c.cent_id=d.cent_id
where r.per_ced=''";
	$result=mysqli_query($conexion,$sql);

 ?>

<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Medicos</label></caption>
	<tr>
		<td>Cita No</td>
		<td>Nota</td>
		<td>Centro Medico</td>
        <td>Fecha y Hora</td>
        <td>Motivo</td>
        <td>Sintomas</td>
        <td>Estado Cita</td>
        <td>Tratamiento</td>
        <td>Medicamento</td>
        <td>Nota Tratamiento</td>
        <td>Esatdo Tratamiento</td>
		
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> </td>
		<td><?php echo $ver[2]; ?></td>
		<td><?php echo $ver[3]; ?></td>
		<td><?php echo $ver[4]; ?></td>
        <td><?php echo $ver[5]; ?></td>
        <td><?php echo $ver[6]; ?></td>
        <td><?php echo $ver[7]; ?></td>
        <td><?php echo $ver[8]; ?></td>
        <td><?php echo $ver[9]; ?></td>
        <td><?php echo $ver[10]; ?></td>
        <td><?php echo $ver[11]; ?></td>
		
	</tr>
<?php endwhile; ?>
</table>