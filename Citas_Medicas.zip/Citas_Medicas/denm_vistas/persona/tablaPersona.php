<?php 
	require_once "../../denn_clases/conexion.php";

	$obj= new conectar();
	$conexion= $obj->conexion();

	$sql="SELECT *
		from tbl_persona where per_estado='A'";
	$result=mysqli_query($conexion,$sql);
 ?>

<div class="table-responsive">
	 <table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	 	<caption><center><label><b>Datos Personales</label></center></caption>
	 	<tr >
            <td ><b>Cedula</td>
	 		<td ><b>Nombres</td>
	 		
	 		<td><b>Genero</td>
             <td><b>Fecha Nacimiento</td>
             <td><b>Telefono</td>
             <td><b>Direccion</td>
	 		<td><b>Estado</td>
	 		
	 		<td colspan="2"> <b>Acciones</td>
	 		
	 	</tr>

	 	<?php while($ver=mysqli_fetch_row($result)): ?>

	 	<tr>
            <td><?php echo $ver[1]; ?></td>
	 		<td><?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
	 		
	 		<td><?php echo $ver[5]; ?></td>
	 		<td><?php echo $ver[6]; ?></td>
	 		
             <td><?php echo $ver[7]; ?></td>
             <td><?php echo $ver[8]; ?></td>
             <td><?php echo $ver[9]; ?></td>
	 		<td>
                <span class="btn btn-warning btn-xs" data-toggle="modal" data-target="#abremodalPersonaUpdate" onclick="agregaDatosPersona('<?php echo $ver[0]; ?>','<?php echo $ver[1] ?>'
                ,'<?php echo $ver[2] ?>','<?php echo $ver[3] ?>','<?php echo $ver[4] ?>','<?php echo $ver[5] ?>','<?php echo $ver[6] ?>'
                ,'<?php echo $ver[7] ?>','<?php echo $ver[8] ?>')">
					<span class="glyphicon glyphicon-pencil"></span>
				</span>
			</td>
			<td>
				<span class="btn btn-danger btn-xs" onclick="eliminarPersona('<?php echo $ver[0]; ?>')">
					<span class="glyphicon glyphicon-remove"></span>
				</span>
			</td>
	 	</tr>
	 <?php endwhile; ?>
	 </table>
</div>