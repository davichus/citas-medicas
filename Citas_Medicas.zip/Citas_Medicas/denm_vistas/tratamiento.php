<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Personas</title>
        <?php require_once "menu.php"; ?>
        <?php require_once "../denn_clases/conexion.php"; 
		$c= new conectar();
		$conexion=$c->conexion();
		$sql="SELECT per_id,per_ced,per_apepat,per_apemat,per_nom
		from tbl_persona";
		$result=mysqli_query($conexion,$sql);
		?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro de Tratamiento</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmTrat">
                    <label>Cita No.</label>
                            <select class="form-control input-sm" id="sl_cita" name="sl_cita">
				<option value="#">Selecciona No de Cita</option>
				<?php
				$sql="SELECT cit_id,
				 cit_asunto
				from tbl_cita";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Tipo de Tratamiento</label>
                            <select class="form-control input-sm" id="sl_trata" name="sl_trata">
				<option value="#">Selecciona Tratmiento</option>
				<?php
				$sql="SELECT tipo_id,
				 tipo_desc
				from tbl_tipo_tratamiento";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Medicamentos</label>
						<textarea  id="txt_med" name="txt_med" class="form-control input-sm"></textarea>
						<label>Nota</label>
						<textarea  id="txt_nota" name="txt_nota" class="form-control input-sm"></textarea>
                        <label>Costo</label>
						<input type="text" class="form-control input-sm" id="txt_costo" name="txt_costo">
                        <label>Estado Pago</label>
							<br>
							<select name="sl_pago" class="form-control input-sm" id="sl_pago" required>
                          <option value="#" disabled selected hidden>--Seleccione--</option>
                          <option value="Pendiente">Pendiente</option>
                          <option value="Pagado">Pagado</option>
                          <option value="Anulado">Anulado</option>
                          </select>
                          <label>Estado Tratamiento</label>
							<br>
							<select name="sl_estado" class="form-control input-sm" id="sl_estado" required>
                          <option value="#" disabled selected hidden>--Seleccione--</option>
                          <option value="Aplicado">Aplicado</option>
                          <option value="No Aplico">No Aplico</option>
                          <option value="Cancelado">Cancelado</option>
                          
                          </select>
						
						<p></p>
						<span class="btn btn-primary" id="btnAgregarTrat">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaTrataLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalTrat" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Datos Personales</h4>
					</div>
					<div class="modal-body">
						<form id="frmTratU">
                        <input type="text" hidden="" id="id" name="id">
						<label>Cita No.</label>
                            <select class="form-control input-sm" id="cita" name="cita">
				<option value="#">Selecciona No de Cita</option>
				<?php
				$sql="SELECT cit_id,
				 cit_asunto
				from tbl_cita";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Tipo de Tratamiento</label>
                            <select class="form-control input-sm" id="trata" name="trata">
				<option value="#">Selecciona Tratmiento</option>
				<?php
				$sql="SELECT tipo_id,
				 tipo_desc
				from tbl_tipo_tratamiento";
				$result=mysqli_query($conexion,$sql);

				while ($producto=mysqli_fetch_row($result)):
					?>
					<option value="<?php echo $producto[0] ?>"><?php echo $producto[1] ?></option>
				<?php endwhile; ?>
            </select>
            <label>Medicamentos</label>
						<textarea  id="med" name="med" class="form-control input-sm"></textarea>
						<label>Nota</label>
						<textarea  id="nota" name="nota" class="form-control input-sm"></textarea>
                        <label>Costo</label>
						<input type="text" class="form-control input-sm" id="costo" name="costo">
                        <label>Estado Pago</label>
							<br>
							<select name="pago" class="form-control input-sm" id="pago" required>
                          <option value="#" disabled selected hidden>--Seleccione--</option>
                          <option value="Pendiente">Pendiente</option>
                          <option value="Pagado">Pagado</option>
                          <option value="Anulado">Anulado</option>
                          </select>
                          <label>Estado Tratamiento</label>
							<br>
							<select name="estado" class="form-control input-sm" id="estado" required>
                          <option value="#" disabled selected hidden>--Seleccione--</option>
                          <option value="Aplicado">Aplicado</option>
                          <option value="No Aplico">No Aplico</option>
                          <option value="Cancelado">Cancelado</option>
                          
                          </select>
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarTratU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaTrataLoad').load("tratamiento/tablaTrata.php");

			$('#btnAgregarTrat').click(function(){

				vacios=validarFormVacio('frmTrat');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmTrat').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/tratamiento/insertaTrata.php",
					success:function(r){
						if(r==2){
							$('#tablaTrataLoad').load("tratamiento/tablaTrata.php");
								alertify.alert("Esta Cita Medica ya consta con un Tratamiento, prueba con otra!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmTrat')[0].reset();

					$('#tablaTrataLoad').load("tratamiento/tablaTrata.php");
					alertify.success("Tratamiento agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar Tratamiento");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarTratU').click(function(){

				datos=$('#frmTratU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/tratamiento/actualizaTrata.php",
					success:function(r){
						if(r==1){
							$('#tablaTrataLoad').load("tratamiento/tablaTrata.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDatosTrat(id){
			$.ajax({
				type:"POST",
				data:"id=" + id,
				url:"../denm_procesos/tratamiento/obtenDatosTrata.php",
				success:function(r){
					
					dato=jQuery.parseJSON(r);
					$('#id').val(dato['trat_id']);
                    $('#cita').val(dato['cit_id']);
					$('#trata').val(dato['tipo_id']);
					$('#med').val(dato['trat_medicamento']);
					$('#nota').val(dato['trat_nota']);
					$('#costo').val(dato['trat_costo']);
					$('#pago').val(dato['trat_estado_pago']);
					$('#estado').val(dato['trat_estado']);
				
				}
			});
		}

		function eliminaTrat(id){
			alertify.confirm('¿Desea seguro que desea cancelar el Tratamiento del Paciente?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/tratamiento/eliminaTrata.php",
					success:function(r){
						if(r==1){
							$('#tablaTrataLoad').load("tratamiento/tablaTrata.php");
							alertify.success("Tratamiento Cancelado!!");
						}else{
							alertify.error("No se pudo Cancelar");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>