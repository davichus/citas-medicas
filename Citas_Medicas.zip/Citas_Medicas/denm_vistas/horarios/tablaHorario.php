<?php 
			require_once "../../denn_clases/conexion.php";
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="SELECT hor_id,hor_inicio,hor_fin,hor_estado 
					FROM tbl_horario where hor_estado='A'";
			$result=mysqli_query($conexion,$sql);
	 ?>


<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Horarios</label></caption>
	<tr>
		<td>Hora Inicio</td>
		<td>Hora Finalizacion</td>
        <td>Estado</td>
		<td colspan="2">Aciones</td>
		
	</tr>

	<?php
	while ($ver=mysqli_fetch_row($result)):
	 ?>

	<tr>
		<td><?php echo $ver[1] ?></td>
        <td><?php echo $ver[2] ?></td>
        <td><?php echo $ver[3] ?></td>
		<td>
			<span class="btn btn-warning btn-xs" data-toggle="modal" data-target="#actualizaHor" onclick="agregaDato('<?php echo $ver[0] ?>','<?php echo $ver[1] ?>','<?php echo $ver[2] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaHor('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>

<?php endwhile; ?>
</table>