<?php 
session_start();
if(isset($_SESSION['usuario'])){

	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
	</head>
	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Registro Centro Medico</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmCentro">
					    <label>Centro Medico</label>
						<input type="text" class="form-control input-sm" id="txt_nom" name="txt_nom">
						<label>Ruc</label>
                        <input type="text" class="form-control input-sm" id="txt_ruc" name="txt_ruc">
                        <label>Direccion</label>
						<input type="text" class="form-control input-sm" id="txt_dir" name="txt_dir">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="txt_telf" name="txt_telf">
						<label>Correo</label>
						<input type="email" class="form-control input-sm" id="txt_correo" name="txt_correo">
                      
						<label>Descripcion</label>
						<textarea  id="txt_desc" name="txt_desc" class="form-control input-sm"></textarea>
						
						<p></p>
						<span class="btn btn-primary" id="btnAgregarCentro">Agregar</span>
					</form>
				</div>
				<div class="col-sm-8">
					<div id="tablaCentroLoad"></div>
				</div>
			</div>
		</div>

		<!-- Button trigger modal -->


		<!-- Modal -->
		<div class="modal fade" id="abremodalCentroUpdate" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Actualizar Centro Medico</h4>
					</div>
					<div class="modal-body">
						<form id="frmCentroU">
                        <input type="text" hidden="" id="id" name="id">
						<label>Centro Medico</label>
						<input type="text" class="form-control input-sm" id="nom" name="nom">
						<label>Ruc</label>
                        <input type="text" class="form-control input-sm" id="ruc" name="ruc">
                        <label>Direccion</label>
						<input type="text" class="form-control input-sm" id="dir" name="dir">
						<label>Telefono</label>
						<input type="text" class="form-control input-sm" id="telf" name="telf">
						<label>Correo</label>
						<input type="email" class="form-control input-sm" id="correo" name="correo">
                      
						<label>Descripcion</label>
						<textarea  id="desc" name="desc" class="form-control input-sm"></textarea>
							
						</form>
					</div>
					<div class="modal-footer">
						<button id="btnAgregarCentroU" type="button" class="btn btn-primary" data-dismiss="modal">Actualizar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
    </html>
    
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaCentroLoad').load("centromedico/tablaCentro.php");

			$('#btnAgregarCentro').click(function(){

				vacios=validarFormVacio('frmCentro');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmCentro').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/centro/agregaCentro.php",
					success:function(r){
						if(r==2){
							$('#tablaCentroLoad').load("centromedico/tablaCentro.php");
								alertify.alert("Este Ruc del Centro Medico ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmCentro')[0].reset();

					$('#tablaCentroLoad').load("centromedico/tablaCentro.php");
					alertify.success("Centro Medico agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar Centro Medico");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnAgregarCentroU').click(function(){

				datos=$('#frmCentroU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/centro/actualizaCentro.php",
					success:function(r){
						if(r==1){
							$('#tablaCentroLoad').load("centromedico/tablaCentro.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDatosCentro(id,nom,ruc,dir,telf,correo,desc){
			$('#id').val(id);
            $('#nom').val(nom);
            $('#ruc').val(ruc);
            $('#dir').val(dir);
            $('#telf').val(telf);
            $('#correo').val(correo);
            $('#desc').val(desc);
          
		}

		function eliminarCentro(id){
			alertify.confirm('¿Desea eliminar este Centro Medico?', function(){ 
				$.ajax({
					type:"POST",
					data:"id=" + id,
					url:"../denm_procesos/centro/eliminarCentro.php",
					success:function(r){
						if(r==1){
							$('#tablaCentroLoad').load("centromedico/tablaCentro.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 
<?php 
}else{
	header("location:../index.php");
}
?>