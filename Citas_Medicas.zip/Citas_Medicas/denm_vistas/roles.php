<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Administrar Roles</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmRol">
						<label>Rol</label>
						<input type="text" class="form-control input-sm" name="txt_rol" id="txt_rol" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
                       
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaRol" name="btnAgregaRol">Registrar Rol</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaRolLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaRol" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Roles</h4>
					</div>
					<div class="modal-body">
						<form id="frmRolU">
							<input type="text" hidden="" id="idrol" name="idrol" onkeypress="return ValidNum(event)" onkeyup="javascript:this.value=this.value.toUpperCase();">
							<label>Rol</label>
							<input type="text" id="rol" name="rol" class="form-control input-sm">
						</form>


					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaRol" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    
					
<script type="text/javascript">
	$(document).ready(function(){
		$('#tablaRolLoad').load("roles/tablaRol.php");

		$('#btnAgregaRol').click(function(){

			if($('#txt_rol').val()==""){
				alertify.alert("Debes agregar el rol");
				return false;
			}

			cadena="rol=" + $('#txt_rol').val() ;

					$.ajax({
						type:"POST",
						url:"../denm_procesos/roles/agregarol.php",
						data:cadena,
						success:function(r){

							if(r==2){
								$('#tablaRolLoad').load("roles/tablaRol.php");
								alertify.alert("Este Rol ya existe, prueba con otro!!");
							}
							else if(r==1){
								$('#frmRol')[0].reset();
								$('#tablaRolLoad').load("roles/tablaRol.php");
								alertify.success("Agregado con exito");
							}else{
								alertify.error("Fallo al agregar");
							}
						}
					});
		});
	});
</script>
	
	
	
	

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaRol').click(function(){

				datos=$('#frmRolU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/roles/actualizaRol.php",
					success:function(r){
						if(r==1){
							$('#tablaRolLoad').load("roles/tablaRol.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(idrol,rol){
			$('#idrol').val(idrol);
			$('#rol').val(rol);
		}

		function eliminaRol(idrol){
			alertify.confirm('¿Desea eliminar este Rol?', function(){ 
				$.ajax({
					type:"POST",
					data:"idrol=" + idrol,
					url:"../denm_procesos/roles/eliminarRol.php",
					success:function(r){
						if(r==1){
							$('#tablaRolLoad').load("roles/tablaRol.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>
