<?php 
session_start();
if(isset($_SESSION['usuario']) and $_SESSION['rol']=='1'){
	?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Citas Medicas</title>
		<?php require_once "menu.php"; ?>
    </head>



	<body>
		<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
			<h1>Administrar Horarios</h1>
			<div class="row">
				<div class="col-sm-4">
					<form id="frmHor">
						<label>Hora de Inicio</label>
						<input type="time" class="form-control input-sm" name="txt_ini" id="txt_ini" >
                        <label>Hora de Finalizacion</label>
						<input type="time" class="form-control input-sm" name="txt_fin" id="txt_fin" >
                       
						<p></p>
						<center><span class="btn btn-primary" id="btnAgregaHor" name="btnAgregaHor">Registrar Horario</span></center>

					</form>
				</div>
				<div class="col-sm-7">
					<div id="tablaHorarioLoad"></div>
				</div>
			</div>
		</div>


		<!-- Button trigger modal -->


		<!-- Modal -->
        <div class="modal fade" id="actualizaHor" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title" id="myModalLabel">Modificar Horarios</h4>
					</div>
					<div class="modal-body">
						<form id="frmHorU">
							<input type="text" hidden="" id="idh" name="idh">
							<label>Hora Inicio</label>
                            <input type="time" id="ini" name="ini" class="form-control input-sm">
                            <label>Hora Finalizacion</label>
							<input type="time" id="fin" name="fin" class="form-control input-sm">
						</form>


					</div>
					<div class="modal-footer">
						<button type="button" id="btnActualizaHor" class="btn btn-warning" data-dismiss="modal">Aceptar</button>

					</div>
				</div>
			</div>
		</div>

	</body>
	</html>
    <script type="text/javascript">
		$(document).ready(function(){

			$('#tablaHorarioLoad').load("horarios/tablaHorario.php");

			$('#btnAgregaHor').click(function(){

				vacios=validarFormVacio('frmHor');

				if(vacios > 0){
					alertify.alert("Debes llenar todos los campos!!");
					return false;
				}

				datos=$('#frmHor').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/horarios/agregaHorario.php",
					success:function(r){
						if(r==2){
							$('#tablaHorarioLoad').load("horarios/tablaHorario.php");
								alertify.alert("Este Horario ya ha sido registrado, prueba con otro!!");
							}
						
						else if(r==1){
					//esta linea nos permite limpiar el formulario al insetar un registro
					$('#frmHor')[0].reset();
          
					$('#tablaHorarioLoad').load("horarios/tablaHorario.php");
					alertify.success("Horario agregado con exito!!");
				}else{
					alertify.error("No se pudo agregar Horario");
				}
			}
		});
			});
		});
	</script>

<script type="text/javascript">
		$(document).ready(function(){
			$('#btnActualizaHor').click(function(){

				datos=$('#frmHorU').serialize();
				$.ajax({
					type:"POST",
					data:datos,
					url:"../denm_procesos/horarios/actualizaHorario.php",
					success:function(r){
						if(r==1){
							$('#tablaHorarioLoad').load("horarios/tablaHorario.php");
							alertify.success("Actualizado con exito !!");
						}else{
							alertify.error("No se pudo actualizar!!!");
						}
					}
				});
			});
		});
    </script>
    <script type="text/javascript">
		function agregaDato(id,ini,fin){
			$('#idh').val(id);
			$('#ini').val(ini);
            $('#fin').val(fin);
		}

		function eliminaHor(id){
			alertify.confirm('¿Desea eliminar este Horario?', function(){ 
				$.ajax({
					type:"POST",
					data:"idh=" + id,
					url:"../denm_procesos/horarios/eliminaHorario.php",
					success:function(r){
						if(r==1){
							$('#tablaHorarioLoad').load("horarios/tablaHorario.php");
							alertify.success("Eliminado con exito!!");
						}else{
							alertify.error("No se pudo eliminar !!!");
						}
					}
				});
			}, function(){ 
				alertify.error('Cancelo !')
			});
		}
	</script>
	
	<script type="text/javascript" language="javascript">
                  function ValidNum(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 47 && tecla < 58 || tecla == 46) {
                          alert("Solo Letras")
                          return false
                      } else {
                          return true
                      }
                  }
                  function Validletra(e) {
                      var tecla = document.all ? tecla = e.keyCode : tecla = e.which;
                      if (tecla > 64 && tecla < 91 || tecla > 96 && tecla < 123) {
                          alert("Solo Numeros")
                          return false
                      } else {
                          return true
                      }
				  }
				  
				

</script> 

<?php 
}else{
	header("location:../index.php");
}
?>
