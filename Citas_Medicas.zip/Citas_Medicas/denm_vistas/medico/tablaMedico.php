<?php 
	require_once "../../denn_clases/conexion.php";
	$c= new conectar();
	$conexion=$c->conexion();
	$sql="SELECT m.med_id,
    p.per_ced,
    p.per_apepat,
    p.per_apemat,
    p.per_nom,
    e.esp_desc,
    h.hor_inicio,
    h.hor_fin,
    c.cent_nombre,
    m.med_estado
FROM tbl_medico m 
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_horario h on m.hor_id=h.hor_id
inner join tbl_centro_medico c on m.cent_id=c.cent_id where med_estado='A'";
	$result=mysqli_query($conexion,$sql);

 ?>

<table class="table table-hover table-condensed table-bordered" style="text-align: center;">
	<caption><label>Medicos</label></caption>
	<tr>
		<td>Persona</td>
		<td>Especialidad</td>
		<td>Horario</td>
        <td>Centro Medico</td>
        <td>Estado</td>
		<td colspan="2">Acciones</td>
		
	</tr>

	<?php while($ver=mysqli_fetch_row($result)): ?>

	<tr>
		<td><?php echo $ver[1]; ?> <?php echo $ver[2]; ?> <?php echo $ver[3]; ?> <?php echo $ver[4]; ?></td>
		<td><?php echo $ver[5]; ?></td>
		<td><?php echo $ver[6]; ?> a <?php echo $ver[7]; ?></td>
		<td><?php echo $ver[8]; ?></td>
		<td><?php echo $ver[9]; ?></td>
		<td>
			<span  data-toggle="modal" data-target="#abremodalMedico" class="btn btn-warning btn-xs" onclick="agregaDatosMedico('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-pencil"></span>
			</span>
		</td>
		<td>
			<span class="btn btn-danger btn-xs" onclick="eliminaMedico('<?php echo $ver[0] ?>')">
				<span class="glyphicon glyphicon-remove"></span>
			</span>
		</td>
	</tr>
<?php endwhile; ?>
</table>