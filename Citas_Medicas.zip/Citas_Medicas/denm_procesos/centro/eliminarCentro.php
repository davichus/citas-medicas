<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/centro.php";

	$obj= new centro;

	echo $obj->eliminaCentro($_POST['id']);

 ?>