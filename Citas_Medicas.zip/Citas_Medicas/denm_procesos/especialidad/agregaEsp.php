<?php 
	session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/especialidad.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$fecha=date("Y-m-d");
	//$idusuario=$_SESSION['iduser'];
	$Esp=$_POST['txt_esp'];

	$datos=array(
		$Esp);

	$obj= new especialidad();
	if(buscaRepetido($Esp,$conexion)==1){
		echo 2;
}else{
	echo $obj->agregaEsp($datos);
}
function buscaRepetido($ced,$conexion){
	$sql="SELECT * from tbl_especialidad 
		where esp_desc='$ced'";
	$result=mysqli_query($conexion,$sql);

	if(mysqli_num_rows($result) > 0){
		return 1;
	}else{
		return 0;
	}
}
 ?>