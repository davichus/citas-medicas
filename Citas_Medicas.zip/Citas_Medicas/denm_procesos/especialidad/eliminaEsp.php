<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/especialidad.php";

	$obj= new especialidad;

	echo $obj->eliminaEsp($_POST['ide']);

 ?>