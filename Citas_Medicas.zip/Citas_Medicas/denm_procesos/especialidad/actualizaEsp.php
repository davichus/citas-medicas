<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/especialidad.php";

	

	$datos=array(
		$_POST['ide'],
		$_POST['esp']
			);

	$obj= new especialidad();

	echo $obj->actualizaEsp($datos);

 ?>