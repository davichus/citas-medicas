<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/personas.php";

	

	$datos=array(
		$_POST['idper'],
        $_POST['ced'],
        $_POST['apepat'],
        $_POST['apemat'],
        $_POST['nom'],
        $_POST['genero'],
        $_POST['fecha'],
        $_POST['telf'],
        $_POST['dir']
			);

	$obj= new personas();

	echo $obj->actualizaPersona($datos);

 ?>