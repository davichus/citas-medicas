<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/tipo.php";

	

	$datos=array(
		$_POST['id'],
		$_POST['nom']
			);

	$obj= new tipo();

	echo $obj->actualizaTipo($datos);

 ?>