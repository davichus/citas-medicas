<?php 
	session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/tipo.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$fecha=date("Y-m-d");
	//$idusuario=$_SESSION['iduser'];
	$Rol=$_POST['txt_nom'];

	$datos=array(
		$Rol);

	$obj= new tipo();
	if(buscaRepetido($Rol,$conexion)==1){
		echo 2;
}else{
	echo $obj->agregaTipo($datos);
}
function buscaRepetido($ced,$conexion){
	$sql="SELECT * from tbl_tipo_tratamiento 
		where tipo_desc='$ced'";
	$result=mysqli_query($conexion,$sql);

	if(mysqli_num_rows($result) > 0){
		return 1;
	}else{
		return 0;
	}
}

 ?>