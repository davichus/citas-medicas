<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/tipo.php";

	$obj= new tipo;

	echo $obj->eliminaTipo($_POST['id']);

 ?>