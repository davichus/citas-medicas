<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/paciente.php";

	$obj= new paciente;

	echo $obj->eliminaPaciente($_POST['id']);

 ?>