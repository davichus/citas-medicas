<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/paciente.php";

	$obj= new paciente();


	$idart=$_POST['id'];

	echo json_encode($obj->obtenDatosPac($idart));

 ?>