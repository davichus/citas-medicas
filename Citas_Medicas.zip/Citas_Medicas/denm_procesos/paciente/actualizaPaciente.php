<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/paciente.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['persona'],
        $_POST['enf'],
        $_POST['ale'],
        $_POST['med']
     
			);

	$obj= new paciente();

	echo $obj->actualizaPaciente($datos);

 ?>