<?php 

session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/paciente.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$obj= new paciente();


	$datos=array(
            $_POST['sl_persona'],
			$_POST['txt_enf'],
			$_POST['txt_ale'],
            $_POST['txt_med']
          
				);
	if(buscaRepetido($_POST['sl_persona'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->insertaPaciente($datos);
	}
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_paciente 
			where per_id='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
	
 ?>