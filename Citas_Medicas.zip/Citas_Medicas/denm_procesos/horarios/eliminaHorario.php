<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/horarios.php";

	$obj= new horarios;

	echo $obj->eliminaHorario($_POST['idh']);

 ?>