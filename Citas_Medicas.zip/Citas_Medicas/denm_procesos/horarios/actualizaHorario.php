<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/horarios.php";

	

	$datos=array(
        $_POST['idh'],
		$_POST['ini'],
        $_POST['fin']

			);

	$obj= new horarios();

	echo $obj->actualizaHorario($datos);

 ?>