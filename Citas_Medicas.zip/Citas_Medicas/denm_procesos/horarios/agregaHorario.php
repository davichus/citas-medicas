<?php 

session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/horarios.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$obj= new horarios();


	$datos=array(
            $_POST['txt_ini'],
			$_POST['txt_fin']
		
				);
	if(buscaRepetido( $_POST['txt_ini'],$_POST['txt_fin'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->agregaHorario($datos);
	}
	function buscaRepetido($ini,$fin,$conexion){
		$sql="SELECT * from tbl_horario 
			where hor_inicio='$ini' and hor_fin='$fin'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
	
 ?>