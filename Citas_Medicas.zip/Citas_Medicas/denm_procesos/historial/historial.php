<?php 
session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/historial.php";

	$obj= new historial();




	$datos=array(
        $_POST['txt_cedula']
	         );
        echo $obj->insertaMedico($datos);
	
	
 ?>

