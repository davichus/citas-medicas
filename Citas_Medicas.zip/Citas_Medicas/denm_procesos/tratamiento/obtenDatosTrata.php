<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/Tratamiento.php";

	$obj= new Tratamiento();


	$idart=$_POST['id'];

	echo json_encode($obj->obtenDatosTrata($idart));

 ?>