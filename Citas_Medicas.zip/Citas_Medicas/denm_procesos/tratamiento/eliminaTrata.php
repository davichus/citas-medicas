<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/Tratamiento.php";

	$obj= new Tratamiento;

	echo $obj->eliminaTrata($_POST['id']);

 ?>