<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/Tratamiento.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['cita'],
        $_POST['trata'],
        $_POST['med'],
        $_POST['nota'],
        $_POST['costo'],
        $_POST['pago'],
        $_POST['estado']
			);

	$obj= new Tratamiento();

	echo $obj->actualizaTrata($datos);

 ?>