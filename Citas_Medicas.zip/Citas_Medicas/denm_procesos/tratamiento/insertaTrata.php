<?php 

session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/Tratamiento.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$obj= new Tratamiento();


	$datos=array(
            $_POST['sl_cita'],
			$_POST['sl_trata'],
			$_POST['txt_med'],
            $_POST['txt_nota'],
            $_POST['txt_costo'],
            $_POST['sl_pago'],
            $_POST['sl_estado']
          
				);
	if(buscaRepetido($_POST['sl_cita'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->insertaTrata($datos);
	}
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_tratamiento 
			where cit_id='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
	
 ?>