<?php
	include '../citas/plantilla.php';
	require "../../denn_clases/conexion2.php";
	
//$codigo=$_POST['codigo'];
$id=$_GET['trat_id'];

$query = "SELECT t.trat_id,
c.cit_asunto,
i.tipo_desc,
t.trat_medicamento,
t.trat_nota,
t.trat_costo,
t.trat_estado_pago,
t.trat_estado,
concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente,
round((t.trat_costo*0.12),2)as subtotal,
round((t.trat_costo*0.12)+t.trat_costo,2)as total
from tbl_tratamiento t 
inner join tbl_cita c on t.cit_id=c.cit_id
inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente a on c.pac_id=a.pac_id
inner join tbl_persona r on a.per_id=r.per_id
where t.trat_id='$id'";
    







$resultado = $mysqli->query($query);
	
	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	
	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',12);
    
	$pdf->Cell(28,6,'Cita No:',1,0,'C',1);
	
	$pdf->SetFont('Arial','',10);
	
	while($row = $resultado->fetch_assoc())
	{
		$pdf->Cell(30,6,utf8_decode($row['cit_asunto']),1,0,'C');
		$pdf->SetFont('Arial','B',12);
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Medico y Especialidad:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['medico']),1,0,'C');
		$pdf->SetFont('Arial','B',12);
		$pdf->Ln(8);
		$pdf->Cell(58,6,'Paciente:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['paciente']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Medicamento',1,0,'C',1); 
		$pdf->Cell(58,6,'Nota',1,0,'C',1);
		$pdf->Cell(58,6,'Estado',1,0,'C',1);
		$pdf->SetFont('Arial','',10);
		$pdf->Ln(8);
		$pdf->Cell(58,6,utf8_decode($row['trat_medicamento']),1,0,'C');
		$pdf->Cell(58,6,utf8_decode($row['trat_nota']),1,0,'C');
		$pdf->Cell(58,6,utf8_decode($row['trat_estado']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Subtotal:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['trat_costo']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Iva 12%:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['subtotal']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Total:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['total']),1,0,'C');

		
	}
	$pdf->Output();
?>