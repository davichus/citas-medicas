<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/citas.php";

	$obj= new citas();


	$idart=$_POST['id'];

	echo json_encode($obj->obtenDatosVita($idart));

 ?>