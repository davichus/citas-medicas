<?php 

session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/citas.php";
    require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();
	$obj= new citas();


	$datos=array(
            $_POST['txt_asunto'],
			$_POST['txt_nota'],
			$_POST['sl_centro'],
            $_POST['sl_medico'],
            $_POST['sl_paciente'],
			$_POST['txt_fecha'],
			$_POST['txt_hora'],
            $_POST['txt_motivo'],
            $_POST['txt_sintomas'],
			$_POST['sl_estado'],
			$_POST['txt_costo'],
            $_POST['sl_pago']
          
				);
	if(buscaRepetido($_POST['txt_asunto'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->insertaCita($datos);
	}
	function buscaRepetido($ced,$conexion){
		$sql="SELECT * from tbl_cita 
			where cit_asunto='$ced'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>