<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/citas.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['asunto'],
        $_POST['nota'],
        $_POST['paciente'],
        $_POST['fecha'],
        $_POST['hora'],
        $_POST['motivo'],
        $_POST['sintomas'],
        $_POST['estado'],
        $_POST['costo'],
        $_POST['pago']
     
			);

	$obj= new citas();

	echo $obj->actualizaCita($datos);

 ?>