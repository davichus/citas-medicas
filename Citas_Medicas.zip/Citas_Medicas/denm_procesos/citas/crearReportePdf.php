<?php
	include 'plantilla.php';
	require "../../denn_clases/conexion2.php";
	
//$codigo=$_POST['codigo'];
$id=$_GET['cit_id'];

$query = "SELECT c.cit_id,
c.cit_asunto,
c.cit_nota,
t.cent_nombre,
concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom, e.esp_desc) as medico,
 concat_ws(' ', o.per_ced, o.per_apepat,o.per_apemat,o.per_nom) as paciente,
 concat_ws(' ',c.cit_fecha,c.cit_hora)as hora,
 c.cit_fecha,
 c.cit_hora,
 c.cit_motivo,
 c.cit_sintomas,
 c.cit_estado,
 c.cit_costo,
 round((c.cit_costo*0.12),2)as subtotal,
 round((c.cit_costo*0.12)+c.cit_costo,2)as total,
 c.cit_estado_pago
FROM tbl_cita c
inner join tbl_centro_medico t on c.cent_id=t.cent_id
inner join tbl_medico m on c.med_id=m.med_id
inner join tbl_persona p on m.per_id=p.per_id
inner join tbl_especialidad e on m.esp_id=e.esp_id
inner join tbl_paciente i on c.pac_id=i.pac_id
inner join tbl_persona o on i.per_id=o.per_id
where c.cit_id='$id'";
    







$resultado = $mysqli->query($query);
	
	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();
	
	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',12);
    
	$pdf->Cell(30,6,'Cita No:',1,0,'C',1);
	
	$pdf->SetFont('Arial','',10);
	
	while($row = $resultado->fetch_assoc())
	{
		$pdf->Cell(30,6,utf8_decode($row['cit_asunto']),1,0,'C');
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(30,6,'Nota:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(84,6,utf8_decode($row['cit_nota']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Centro Medico:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['cent_nombre']),1,0,'C');
		$pdf->SetFont('Arial','B',12);
		$pdf->Ln(8);
		$pdf->Cell(58,6,'Medico y Especialidad:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['medico']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Paciente',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['paciente']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Fecha y Hora',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(116,6,utf8_decode($row['hora']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'Motivo',1,0,'C',1); 
		$pdf->Cell(58,6,'Sintomas',1,0,'C',1);
		$pdf->Cell(58,6,'Estado',1,0,'C',1);
		$pdf->SetFont('Arial','',10);
		$pdf->Ln(8);
		$pdf->Cell(58,6,utf8_decode($row['cit_motivo']),1,0,'C');
		$pdf->Cell(58,6,utf8_decode($row['cit_sintomas']),1,0,'C');
		$pdf->Cell(58,6,utf8_decode($row['cit_estado']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Subtotal:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['cit_costo']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Iva 12%:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['subtotal']),1,0,'C');
		$pdf->Ln(8);
		$pdf->SetFont('Arial','B',12);
		$pdf->Cell(58,6,'',0,0,'C',0); 
		$pdf->Cell(58,6,'Total:',1,0,'C',1); 
		$pdf->SetFont('Arial','',10);
		$pdf->Cell(58,6,utf8_decode($row['total']),1,0,'C');

		
	}
	$pdf->Output();
?>