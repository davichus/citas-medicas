<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/usuarios.php";
	require_once "../../denn_clases/conexion1.php";
	require_once "../../denn_clases/SED.php";
    $conexion=conexion();
	$obj= new usuarios();
    
	//$pass=sha1($_POST['txt_pass']);
	$contrasena=SED::encryption($_POST['txt_pass']);
	$datos=array(
		$_POST['sl_persona'],
		$_POST['txt_correo'],
		$_POST['txt_usuario'],
		$contrasena,
		$_POST['sl_rol']
				);
	if(buscaRepetido($_POST['sl_persona'],$_POST['txt_usuario'],$_POST['txt_correo'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->registroUsuario($datos);
   }
 

	function buscaRepetido($per,$usu,$correo,$conexion){
		$sql="SELECT * from tbl_usuario 
			where per_id='$per' or usu_nomlogin='$usu' or usu_correo='$correo'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}

 ?>