<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/medico.php";

	$obj= new medico;

	echo $obj->eliminaMedico($_POST['id']);

 ?>