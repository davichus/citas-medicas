<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/medico.php";

	$obj= new medico();


	$idart=$_POST['id'];

	echo json_encode($obj->obtenDatosMedico($idart));

 ?>