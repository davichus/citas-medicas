<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/medico.php";

	

	$datos=array(
		$_POST['id'],
        $_POST['persona'],
        $_POST['esp'],
        $_POST['hor'],
        $_POST['centro']
     
			);

	$obj= new medico();

	echo $obj->actualizaMeedico($datos);

 ?>