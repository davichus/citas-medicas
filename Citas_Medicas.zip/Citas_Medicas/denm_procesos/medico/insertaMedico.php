<?php 

session_start();
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/medico.php";
	require_once "../../denn_clases/conexion1.php";
    $conexion=conexion();

	$obj= new medico();


	$datos=array(
            $_POST['sl_persona'],
			$_POST['sl_esp'],
			$_POST['sl_hor'],
            $_POST['sl_centro']
          
				);
	if(buscaRepetido($_POST['sl_persona'],$conexion)==1){
					echo 2;
	}else{
	echo $obj->insertaMedico($datos);
	}
	function buscaRepetido($pac,$conexion){
		$sql="SELECT * from tbl_medico 
			where per_id='$pac'";
		$result=mysqli_query($conexion,$sql);

		if(mysqli_num_rows($result) > 0){
			return 1;
		}else{
			return 0;
		}
	}
	
 ?>