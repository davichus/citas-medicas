<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/usuarios.php";

	$obj= new usuarios;

	echo $obj->eliminaUsuario($_POST['id']);

 ?>