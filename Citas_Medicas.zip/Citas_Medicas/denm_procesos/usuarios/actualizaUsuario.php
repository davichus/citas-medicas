<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/usuarios.php";
    require_once "../../denn_clases/SED.php";
	$obj= new usuarios;
	
	$contrasena=SED::encryption($_POST['pass']);
	$datos=array(
			$_POST['id'],  
		    $_POST['correo'] , 
			$_POST['usu'],
			$contrasena,  
            $_POST['rol']
            
				);  
	echo $obj->actualizaUsuario($datos);


 ?>