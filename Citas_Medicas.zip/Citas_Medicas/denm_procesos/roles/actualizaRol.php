<?php 
	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/roles.php";

	

	$datos=array(
		$_POST['idrol'],
		$_POST['rol']
			);

	$obj= new roles();

	echo $obj->actualizaRol($datos);

 ?>