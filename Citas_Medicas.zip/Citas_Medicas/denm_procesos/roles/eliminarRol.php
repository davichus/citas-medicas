<?php 

	require_once "../../denn_clases/conexion.php";
	require_once "../../denn_clases/roles.php";

	$obj= new roles;

	echo $obj->eliminaRol($_POST['idrol']);

 ?>