<?php 
	class historial{
    
        public function insertaMedico($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="select t.trat_id,
            c.cit_asunto,
            c.cit_nota,
            d.cent_nombre,
            concat_ws(' ',c.cit_fecha,c.cit_hora) as fecha,
            c.cit_motivo,
            c.cit_sintomas,
            c.cit_estado,
            i.tipo_desc,
            t.trat_medicamento,
            t.trat_nota,
            t.trat_estado,
            concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
            concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente
        from tbl_tratamiento t 
        inner join tbl_cita c on t.cit_id=c.cit_id
        inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
        inner join tbl_medico m on c.med_id=m.med_id
        inner join tbl_persona p on m.per_id=p.per_id
        inner join tbl_especialidad e on m.esp_id=e.esp_id
        inner join tbl_paciente a on c.pac_id=a.pac_id
        inner join tbl_persona r on a.per_id=r.per_id
        inner join tbl_centro_medico d on c.cent_id=d.cent_id
				where r.per_ced='$datos'";
			return mysqli_query($conexion,$sql);
		}

		public function obtenDatosHistorial($id){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="select t.trat_id,
            c.cit_asunto,
            c.cit_nota,
            d.cent_nombre,
            concat_ws(' ',c.cit_fecha,c.cit_hora) as fecha,
            c.cit_motivo,
            c.cit_sintomas,
            c.cit_estado,
            i.tipo_desc,
            t.trat_medicamento,
            t.trat_nota,
            t.trat_estado,
            concat_ws(' ', p.per_ced, p.per_apepat,p.per_apemat,p.per_nom,e.esp_desc) as medico,
            concat_ws(' ', r.per_ced, r.per_apepat,r.per_apemat,r.per_nom) as paciente
        from tbl_tratamiento t 
        inner join tbl_cita c on t.cit_id=c.cit_id
        inner join tbl_tipo_tratamiento i on t.tipo_id=i.tipo_id
        inner join tbl_medico m on c.med_id=m.med_id
        inner join tbl_persona p on m.per_id=p.per_id
        inner join tbl_especialidad e on m.esp_id=e.esp_id
        inner join tbl_paciente a on c.pac_id=a.pac_id
        inner join tbl_persona r on a.per_id=r.per_id
        inner join tbl_centro_medico d on c.cent_id=d.cent_id
				where r.per_ced='$id'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);

			$datos=array(
					"trat_id" => $ver[0],
					"cit_asunto" => $ver[1],
					"cit_nota" => $ver[2],
                    "cent_nombre" => $ver[3],
                    "fecha" => $ver[4],
                    "cit_motivo" => $ver[5],
                    "cit_sintomas" => $ver[6],
                    "cit_estado" => $ver[7],
                    "tipo_desc" => $ver[8],
                    "trat_medicamento" => $ver[9],
                    "trat_nota" => $ver[10],
                    "trat_estado" => $ver[11],
                    "medico" => $ver[12],
                    "paciente" => $ver[13]
						);

			return $datos;
		}

		
        
		
	}

 ?>