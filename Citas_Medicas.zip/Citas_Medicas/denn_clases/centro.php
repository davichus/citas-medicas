<?php 

	class centro{

		public function agregaCentro($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_centro_medico(cent_nombre,
                                          cent_ruc,
                                          cent_dir,
                                          cent_telf,
                                          cent_correo,
                                          cent_desc,
                                          cent_estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaCentro($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_centro_medico set cent_nombre='$datos[1]',
                                         cent_ruc='$datos[2]',
                                         cent_dir='$datos[3]',
                                         cent_telf='$datos[4]',
                                         cent_correo='$datos[5]',
                                         cent_desc='$datos[6]'
								where cent_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaCentro($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_centro_medico set cent_estado='I'
								where cent_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>