<?php 

	class tipo{

		public function agregaTipo($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_tipo_tratamiento(tipo_desc,
										tipo_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaTipo($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tipo_tratamiento set tipo_desc='$datos[1]'
								where tipo_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaTipo($tipo_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tipo_tratamiento set tipo_estado='I'
								where tipo_id='$tipo_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>