<?php 

	class especialidad{

		public function agregaEsp($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_especialidad(esp_desc,
										esp_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaEsp($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_especialidad set esp_desc='$datos[1]'
								where esp_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaEsp($esp_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_especialidad set esp_estado='I'
								where esp_id='$esp_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>