<?php
require("../denn_clases/conexion1.php");
$prove = mysqli_real_escape_string($con, $_POST["cent_id"]);
$query = 'SELECT * FROM tbl_medico WHERE cent_id = "'.$prove.'"';
$result = mysqli_query($con, $query);
while($row = mysqli_fetch_array($result, $MYSQL_ASSOC))
{
    echo '<option value="' .$row["med_id"]. '">' .$row["esp_id"]. '</option>';
}
mysqli_close($con);
?>