<?php 

	class roles{

	 function buscaRepetido($desc){
			$c= new conectar();
			$sql="SELECT *from tbl_tipoperfil where Tper_desperfil='$desc'";
			$conexion=$c->conexion();
			$result=mysqli_query($conexion,$sql);

			if(mysqli_num_rows($result) > 0){
				return 1;
			}else{
				return 0;
			}
		}



		public function agregaRol($datos){
			$c= new conectar();
			$conexion=$c->conexion();
		 
		
			$sql="INSERT into tbl_tipoperfil(Tper_desperfil,
										Tper_estado)
						values ('$datos[0]',
								'A')";

			return mysqli_query($conexion,$sql);
		
		}
		
       
		

		public function actualizaRol($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tipoperfil set Tper_desperfil='$datos[1]'
								where Tper_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaRol($Tper_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tipoperfil set Tper_estado='I'
								where Tper_id='$Tper_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>
	