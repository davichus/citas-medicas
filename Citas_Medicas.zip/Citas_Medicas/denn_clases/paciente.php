<?php 
	class paciente{
	
		public function insertaPaciente($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="INSERT into tbl_paciente (per_id,
										pac_enfermedad,
										pac_alergias,
										pac_medicamento,
										pac_estado) 
							values ('$datos[0]',
									'$datos[1]',
									'$datos[2]',
									'$datos[3]',
									'A')";
			return mysqli_query($conexion,$sql);
		}

		public function obtenDatosPac($id){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="SELECT pac_id, 
						per_id, 
						pac_enfermedad,
						pac_alergias,
						pac_medicamento
				from tbl_paciente 
				where pac_id='$id'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);

			$datos=array(
					"pac_id" => $ver[0],
					"per_id" => $ver[1],
					"pac_enfermedad" => $ver[2],
					"pac_alergias" => $ver[3],
					"pac_medicamento" => $ver[4]
						);

			return $datos;
		}

		public function actualizaPaciente($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_paciente set per_id='$datos[1]', 
										pac_enfermedad='$datos[2]',
										pac_alergias='$datos[3]',
										pac_medicamento='$datos[4]'
						where pac_id='$datos[0]'";

			return mysqli_query($conexion,$sql);
		}

        public function eliminaPaciente($id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_paciente set pac_estado='I'
								where pac_id='$id'";
			echo mysqli_query($conexion,$sql);
		}
		
	}

 ?>