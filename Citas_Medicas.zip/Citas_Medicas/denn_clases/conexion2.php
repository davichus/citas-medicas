<?php
	
	$mysqli = new mysqli('localhost', 'root', '', 'citas_medicas');
	
	if($mysqli->connect_error){
		
		die('Error en la conexion' . $mysqli->connect_error);
		
	}
?>