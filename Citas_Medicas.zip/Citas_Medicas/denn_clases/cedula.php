<?php 
  
  class cedula{
   public static boolean CedulaCorreta(string $cedula){
  
  
    return false;
   }

  }
?>