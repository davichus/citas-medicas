<?php 

	class personas{

		public function agregaPersona($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_persona(per_ced,
                                          per_apepat,
                                          per_apemat,
                                          per_nom,
                                          per_genero,
                                          per_fechanac,
                                          per_telef,
                                          per_direccion,
										  per_estado)
						values ('$datos[0]',
                               '$datos[1]',
                               '$datos[2]',
                               '$datos[3]',
                               '$datos[4]',
                               '$datos[5]',
                               '$datos[6]',
                               '$datos[7]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaPersona($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_persona set per_ced='$datos[1]',
                                         per_apepat='$datos[2]',
                                         per_apemat='$datos[3]',
                                         per_nom='$datos[4]',
                                         per_genero='$datos[5]',
                                         per_fechanac='$datos[6]',
                                         per_telef='$datos[7]',
                                         per_direccion='$datos[8]'
								where per_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaPersona($per_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_persona set per_estado='I'
								where per_id='$per_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>