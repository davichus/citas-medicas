<?php 
	class medico{
	
		public function insertaMedico($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="INSERT into tbl_medico (per_id,
										esp_id,
										hor_id,
										cent_id,
										med_estado) 
							values ('$datos[0]',
									'$datos[1]',
									'$datos[2]',
									'$datos[3]',
									'A')";
			return mysqli_query($conexion,$sql);
		}

		public function obtenDatosMedico($id){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="SELECT med_id, 
						per_id, 
						esp_id,
						hor_id,
						cent_id
				from tbl_medico 
				where med_id='$id'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);

			$datos=array(
					"med_id" => $ver[0],
					"per_id" => $ver[1],
					"esp_id" => $ver[2],
					"hor_id" => $ver[3],
					"cent_id" => $ver[4]
						);

			return $datos;
		}

		public function actualizaMeedico($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_medico set per_id='$datos[1]', 
										esp_id='$datos[2]',
										hor_id='$datos[3]',
										cent_id='$datos[4]'
						where med_id='$datos[0]'";

			return mysqli_query($conexion,$sql);
		}

        public function eliminaMedico($id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_medico set med_estado='I'
								where med_id='$id'";
			echo mysqli_query($conexion,$sql);
		}
		
	}

 ?>