<?php 
     require_once "SED.php";
	class usuarios{
		public function registroUsuario($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="INSERT into tbl_usuario (per_id,
								usu_correo,
								usu_nomlogin,
								usu_pass,
                                Tper_id,
								usu_estado,
								usu_fecha)
						values ('$datos[0]',
								'$datos[1]',
								'$datos[2]',
								'$datos[3]',
                                '$datos[4]',
								'A',
								'$fecha')";
			return mysqli_query($conexion,$sql);
		}
		public function loginUser($datos){
			$c=new conectar();
			$conexion=$c->conexion();
           //$contrasena=SED::encryption($datos[1]);

			//$password=sha1($datos[1]);
			$_SESSION['rol']=self::traeRol($datos);
		
			$_SESSION['usuario']=$datos[0];
			
			$_SESSION['iduser']=self::traeID($datos);

			$sql="SELECT * 
				from tbl_usuario 
				where usu_nomlogin='$datos[0]'
				and usu_pass='$datos[1]'";
			$result=mysqli_query($conexion,$sql);

			if(mysqli_num_rows($result) > 0){
				return 1;
			}else{
				return 0;
			}
		}
		public function traeRol($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			//$password=sha1($datos[1]);
            //$contrasena=SED::encryption($datos[1]);
			$sql="SELECT Tper_id
					from tbl_usuario 
					where usu_nomlogin='$datos[0]'
					and usu_pass='$datos[1]'"; 
			$result=mysqli_query($conexion,$sql);

			return mysqli_fetch_row($result)[0];
		}
		public function traeID($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			//$password=sha1($datos[1]);
			//$contrasena=SED::encryption($datos[1]);
			$sql="SELECT usu_id 
					from tbl_usuario 
					where usu_nomlogin='$datos[0]'
					and usu_pass='$datos[1]'"; 
			$result=mysqli_query($conexion,$sql);

			return mysqli_fetch_row($result)[0];
		}

		public function obtenDatosUsuario($idusuario){

			$c=new conectar();
			$conexion=$c->conexion();
            
			$sql="SELECT usu_id,
			per_id,
			   usu_correo,
			   usu_nomlogin,
			   usu_pass,
			   Tper_id,
			   usu_estado  
	   from tbl_usuario 
					where usu_id='$idusuario'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);
		    $contrasena=SED::decryption($ver[4]);
			$datos=array(
				
						'usu_id' => $ver[0],
							'per_id' => $ver[1],
							'usu_correo' => $ver[2],
							'usu_nomlogin' => $ver[3],
							'usu_pass' => $contrasena,
							'Tper_id' => $ver[5],
							'usu_estado' => $ver[6]
							
						);

			return $datos;
		}

		public function actualizaUsuario($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_usuario set usu_correo='$datos[1]',
									usu_nomlogin='$datos[2]',
                                    usu_pass='$datos[3]',
									Tper_id='$datos[4]'
						where usu_id='$datos[0]'";
			return mysqli_query($conexion,$sql);	
		}

		public function eliminaUsuario($idusuario){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="DELETE from tbl_usuario 
					where usu_id='$idusuario'";
			return mysqli_query($conexion,$sql);
		}
	}

 ?>