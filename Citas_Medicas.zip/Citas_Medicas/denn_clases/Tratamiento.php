<?php 
	class Tratamiento{
	
		public function insertaTrata($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="INSERT into tbl_tratamiento (cit_id,
										tipo_id,
										trat_medicamento,
										trat_nota,
                                        trat_costo,
                                        trat_estado_pago,
                                        trat_estado
                                        ) 
							values ('$datos[0]',
									'$datos[1]',
									'$datos[2]',
									'$datos[3]',
                                    '$datos[4]',
                                    '$datos[5]',
                                    '$datos[6]'
                                        )";
			return mysqli_query($conexion,$sql);
		}

		public function obtenDatosTrata($id){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="SELECT trat_id, 
						cit_id,
						tipo_id,
                        trat_medicamento,
                        trat_nota,
                        trat_costo,
                        trat_estado_pago,
                        trat_estado
                        
                 from tbl_tratamiento
				where trat_id='$id'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);

			$datos=array(
					"trat_id" => $ver[0],
					"cit_id" => $ver[1],
					"tipo_id" => $ver[2],
                    "trat_medicamento" => $ver[3],
					"trat_nota" => $ver[4],
					"trat_costo" => $ver[5],
                    "trat_estado_pago" => $ver[6],
                    "trat_estado" => $ver[7]
						);

			return $datos;
		}

		public function actualizaTrata($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tratamiento set   cit_id='$datos[1]', 
										tipo_id='$datos[2]',
										trat_medicamento='$datos[3]',
										trat_nota='$datos[4]',
										trat_costo='$datos[5]',
										trat_estado_pago='$datos[6]',
                                        trat_estado='$datos[7]'
						where trat_id='$datos[0]'";

			return mysqli_query($conexion,$sql);
		}

        public function eliminaTrata($id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_tratamiento set trat_estado='Cancelado'
								where trat_id='$id'";
			echo mysqli_query($conexion,$sql);
		}
		
	}

 ?>