<?php 
	class citas{
	
		public function insertaCita($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$fecha=date('Y-m-d');

			$sql="INSERT into tbl_cita (cit_asunto,
										cit_nota,
										cent_id,
										med_id,
                                        pac_id,
                                        cit_fecha,
                                        cit_hora,
                                        cit_motivo,
                                        cit_sintomas,
                                        cit_estado,
                                        cit_costo,
                                        cit_estado_pago) 
							values ('$datos[0]',
									'$datos[1]',
									'$datos[2]',
									'$datos[3]',
                                    '$datos[4]',
                                    '$datos[5]',
                                    '$datos[6]',
                                    '$datos[7]',
                                    '$datos[8]',
                                    '$datos[9]',
                                    '$datos[10]',
                                    '$datos[11]')";
			return mysqli_query($conexion,$sql);
		}

		public function obtenDatosVita($id){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="SELECT cit_id, 
						cit_asunto,
						cit_nota,
                        pac_id,
                        cit_fecha,
                        cit_hora,
                        cit_motivo,
                        cit_sintomas,
                        cit_estado,
                        cit_costo,
                        cit_estado_pago
				from tbl_cita 
				where cit_id='$id'";
			$result=mysqli_query($conexion,$sql);

			$ver=mysqli_fetch_row($result);

			$datos=array(
					"cit_id" => $ver[0],
					"cit_asunto" => $ver[1],
					"cit_nota" => $ver[2],
                    "pac_id" => $ver[3],
					"cit_fecha" => $ver[4],
					"cit_hora" => $ver[5],
					"cit_motivo" => $ver[6],
                    "cit_sintomas" => $ver[7],
                    "cit_estado" => $ver[8],
                    "cit_costo" => $ver[9],
                    "cit_estado_pago" => $ver[10]
						);

			return $datos;
		}

		public function actualizaCita($datos){
			$c=new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_cita set   cit_asunto='$datos[1]', 
										cit_nota='$datos[2]',
										pac_id='$datos[3]',
										cit_fecha='$datos[4]',
										cit_hora='$datos[5]',
										cit_motivo='$datos[6]',
										cit_sintomas='$datos[7]',
										cit_estado='$datos[8]',
										cit_costo='$datos[9]',
										cit_estado_pago='$datos[10]'
						where cit_id='$datos[0]'";

			return mysqli_query($conexion,$sql);
		}

        public function eliminaCita($id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_cita set cit_estado='Cancelada'
								where cit_id='$id'";
			echo mysqli_query($conexion,$sql);
		}
		
	}

 ?>