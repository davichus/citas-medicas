<?php 

	class horarios{

		public function agregaHorario($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="INSERT into tbl_horario(hor_inicio,
                                          hor_fin,
                                          hor_estado)
						values ('$datos[0]',
                                '$datos[1]',
								'A')";

			return mysqli_query($conexion,$sql);
		}

		public function actualizaHorario($datos){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_horario set hor_inicio='$datos[1]',
                                          hor_fin='$datos[2]' 
								where hor_id='$datos[0]'";
			echo mysqli_query($conexion,$sql);
		}
		public function eliminaHorario($hor_id){
			$c= new conectar();
			$conexion=$c->conexion();

			$sql="UPDATE tbl_horario set hor_estado='I'
								where hor_id='$hor_id'";
			echo mysqli_query($conexion,$sql);
		}
		
		
		//public function eliminaRol($Tper_id){
			//$c= new conectar();
			//$conexion=$c->conexion();
			//$sql="DELETE from tbl_tipoperfil 
					//where Tper_id='$Tper_id'";
			//return mysqli_query($conexion,$sql);
		//}

	}

 ?>