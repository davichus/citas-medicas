<?php 
	
	require_once "denn_clases/conexion.php";
	$obj= new conectar();
	$conexion=$obj->conexion();

    $sql="SELECT * FROM tbl_usuario u inner join tbl_tipoperfil t on u.Tper_id=t.Tper_id where t.Tper_desperfil='Administrador'";
	$result=mysqli_query($conexion,$sql);
	$validar=0;
	if(mysqli_num_rows($result) > 0){
		$validar=1;
	}
 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Lumino - Login</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/datepicker3.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <script src="js/funciones.js"></script>
	<!--[if lt IE 9]>
	<script src="js/html5shiv.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
</head>
<body>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading"><center>Ingreso al Sistema</center></div>
				<div class="panel-body">
             
						<fieldset>
                        <form id="frmLogin" onsubmit="return validar()" >
							<div class="form-group">
								<input class="form-control" placeholder="Usuario" name="txt_usu" id="txt_usu" type="text" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Contraseña" name="txt_pass" id="txt_pass" type="password" value="">
							</div>
						
                      
                            <!--<a href="index.html" class="btn btn-primary">Login</a>-->
                            
                            <center>
                            <!--<input type="submit" class="btn btn-primary btn-sm" id="entrarSistema" value="Ingresar" tyle="font-size: 1.25em">-->
                            
                        <span class="btn btn-primary btn-sm" id="entrarSistema" style="font-size: 1.25em">Ingresar</span>
							<?php  if(!$validar): ?>
							<a href="registro.php" class="btn btn-danger btn-sm" style="font-size: 1.25em">Registrar</a>
							<?php endif; ?></center>
                            
                            </fieldset>
					
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	

<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
	$(document).ready(function(){
		$('#entrarSistema').click(function(){

		//obteniendo el valor que se puso en el campo text del formulario
 var miCampoTexto = document.getElementById("txt_usu").value;
 //la condición
 if (miCampoTexto.length == 0 || /^\s+$/.test(miCampoTexto)) {
     alert('Ingrese su Usuario!');
     return false;
 }
    
 //Validando el combo select
 var miCombo = document.getElementById("txt_pass").value;
 if(miCombo == ""){
     alert('Ingrese su Contraseña');
     return false;
 }

        
        
        //vacios=validarFormVacio('frmLogin');
        
			//if(vacios > 0){
				//alert("Debes llenar todos los campos!!");
				//return false;
			//}

		datos=$('#frmLogin').serialize();
		$.ajax({
			type:"POST",
			data:datos,
			url:"denm_procesos/regLogin/login.php",
			success:function(r){

				if(r==1){
					window.location="denm_vistas/inicio.php";
				}else{
					alert("No se pudo acceder !!");
				}
			}
		});
	});
	});
</script>

<script type="text/javascript">
    function validar() {
 //obteniendo el valor que se puso en el campo text del formulario
 var miCampoTexto = document.getElementById("txt_usu").value;
 //la condición
 if (miCampoTexto.length == 0 || /^\s+$/.test(miCampoTexto)) {
     alert('Ingrese su Usuario!');
     return false;
 }
    
 //Validando el combo select
 var miCombo = document.getElementById("txt_pass").value;
 if(miCombo == ""){
     alert('Ingrese su Contraseña');
     return false;
 }

 return true;
 }
</script>



</body>
</html>
