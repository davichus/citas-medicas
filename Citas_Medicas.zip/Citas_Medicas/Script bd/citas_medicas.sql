-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 19-06-2020 a las 18:35:46
-- Versión del servidor: 10.4.8-MariaDB
-- Versión de PHP: 7.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `citas_medicas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_centro_medico`
--

CREATE TABLE `tbl_centro_medico` (
  `cent_id` int(11) NOT NULL,
  `cent_nombre` varchar(200) DEFAULT NULL,
  `cent_ruc` varchar(200) DEFAULT NULL,
  `cent_dir` varchar(200) NOT NULL,
  `cent_telf` varchar(200) DEFAULT NULL,
  `cent_correo` varchar(200) DEFAULT NULL,
  `cent_desc` varchar(200) DEFAULT NULL,
  `cent_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_centro_medico`
--

INSERT INTO `tbl_centro_medico` (`cent_id`, `cent_nombre`, `cent_ruc`, `cent_dir`, `cent_telf`, `cent_correo`, `cent_desc`, `cent_estado`) VALUES
(1, 'Centro Médico Integral AXXIS', '1750982405001', 'N39-158 (260 Av. Vozandes y Av. America, 170104', '(02) 382-4440', 'info@axxis.com.ec', 'AXXIS Centro Médico Integral', 'A'),
(2, 'CENTRO DE SALUD COTOCOLLAO', '1758964256001', 'Av. John F. Kennedy S/N, Quito 170301', '(02) 253-0787', 'info@cotocollao.com', 'Centro de salud Publico', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cita`
--

CREATE TABLE `tbl_cita` (
  `cit_id` int(11) NOT NULL,
  `cit_asunto` varchar(100) DEFAULT NULL,
  `cit_nota` varchar(100) DEFAULT NULL,
  `cent_id` int(11) DEFAULT NULL,
  `med_id` int(11) DEFAULT NULL,
  `pac_id` int(11) DEFAULT NULL,
  `cit_fecha` varchar(100) DEFAULT NULL,
  `cit_hora` varchar(50) DEFAULT NULL,
  `cit_motivo` varchar(200) DEFAULT NULL,
  `cit_sintomas` varchar(200) DEFAULT NULL,
  `cit_estado` varchar(200) DEFAULT NULL,
  `cit_costo` float DEFAULT NULL,
  `cit_estado_pago` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_cita`
--

INSERT INTO `tbl_cita` (`cit_id`, `cit_asunto`, `cit_nota`, `cent_id`, `med_id`, `pac_id`, `cit_fecha`, `cit_hora`, `cit_motivo`, `cit_sintomas`, `cit_estado`, `cit_costo`, `cit_estado_pago`) VALUES
(5, 'cita 001', 'Chequeo General', 1, 1, 2, '2020-06-02', '13:00', 'Gripe', 'Fiebre, Toz', 'Aplicada', 25, 'Pagado'),
(6, 'cita 002', 'Chequeo General', 1, 1, 1, '2020-06-02', '14:00', 'Gripe', 'Tos seca', 'Aplicada', 25, 'Pagado'),
(7, 'cita 003', 'Cheque General', 1, 1, 2, '2020-06-08', '09:00', 'Dolor de Cabeza', 'Dolor de Cabeza', 'Cancelada', 25, 'Pagado'),
(8, 'cita 004', 'Chequeo General', 1, 1, 1, '2020-06-09', '18:00', 'Toz', 'Fiebre', 'Aplicada', 30, 'Pagado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_especialidad`
--

CREATE TABLE `tbl_especialidad` (
  `esp_id` int(11) NOT NULL,
  `esp_desc` varchar(50) DEFAULT NULL,
  `esp_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_especialidad`
--

INSERT INTO `tbl_especialidad` (`esp_id`, `esp_desc`, `esp_estado`) VALUES
(1, 'TRAUMATOLOGIA', 'A'),
(2, 'DERMATOLOGIA', 'A'),
(3, 'OFTALMOLOGIA', 'A'),
(4, 'MEDICO GENERAL', 'A'),
(5, 'GINECOLOGIA', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_horario`
--

CREATE TABLE `tbl_horario` (
  `hor_id` int(11) NOT NULL,
  `hor_inicio` varchar(30) DEFAULT NULL,
  `hor_fin` varchar(30) DEFAULT NULL,
  `hor_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_horario`
--

INSERT INTO `tbl_horario` (`hor_id`, `hor_inicio`, `hor_fin`, `hor_estado`) VALUES
(2, '08:00', '17:00', 'A'),
(3, '08:00', '12:00', 'A'),
(4, '13:00', '17:00', 'A'),
(5, '08:30', '17:30', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_medico`
--

CREATE TABLE `tbl_medico` (
  `med_id` int(11) NOT NULL,
  `per_id` int(11) DEFAULT NULL,
  `esp_id` int(11) DEFAULT NULL,
  `hor_id` int(11) DEFAULT NULL,
  `cent_id` int(11) DEFAULT NULL,
  `med_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_medico`
--

INSERT INTO `tbl_medico` (`med_id`, `per_id`, `esp_id`, `hor_id`, `cent_id`, `med_estado`) VALUES
(1, 1, 4, 2, 1, 'A'),
(2, 2, 1, 2, 2, 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_paciente`
--

CREATE TABLE `tbl_paciente` (
  `pac_id` int(11) NOT NULL,
  `per_id` int(11) DEFAULT NULL,
  `pac_enfermedad` varchar(200) DEFAULT NULL,
  `pac_alergias` varchar(200) DEFAULT NULL,
  `pac_medicamento` varchar(200) DEFAULT NULL,
  `pac_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_paciente`
--

INSERT INTO `tbl_paciente` (`pac_id`, `per_id`, `pac_enfermedad`, `pac_alergias`, `pac_medicamento`, `pac_estado`) VALUES
(1, 2, 'Ninguna', 'Ninguna', 'Ninguna', 'A'),
(2, 3, 'Ninguna', 'Rinitis alergica', 'Loratadina, Afrin, Suero Fisiologico', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_persona`
--

CREATE TABLE `tbl_persona` (
  `per_id` int(11) NOT NULL,
  `per_ced` varchar(10) DEFAULT NULL,
  `per_apepat` varchar(100) DEFAULT NULL,
  `per_apemat` varchar(100) DEFAULT NULL,
  `per_nom` varchar(100) DEFAULT NULL,
  `per_genero` varchar(30) DEFAULT NULL,
  `per_fechanac` varchar(30) DEFAULT NULL,
  `per_telef` varchar(10) DEFAULT NULL,
  `per_direccion` varchar(100) DEFAULT NULL,
  `per_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_persona`
--

INSERT INTO `tbl_persona` (`per_id`, `per_ced`, `per_apepat`, `per_apemat`, `per_nom`, `per_genero`, `per_fechanac`, `per_telef`, `per_direccion`, `per_estado`) VALUES
(1, '1750982405', 'Navarrete', 'Morales', 'David Efrain', 'M', '1998-12-03', '0969678528', 'Carapungo', 'A'),
(2, '1710962836', 'Campaña', 'Naranjo', 'Luis Fernando', 'M', '1968-11-06', '0984002445', 'Carapungo', 'A'),
(3, '1725347353', 'Campaña', 'Morales', 'Karla Sofia', 'F', '2003-04-04', '2429795', 'CARAPUNGO ', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tipoperfil`
--

CREATE TABLE `tbl_tipoperfil` (
  `Tper_id` int(11) NOT NULL,
  `Tper_desperfil` varchar(50) DEFAULT NULL,
  `Tper_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_tipoperfil`
--

INSERT INTO `tbl_tipoperfil` (`Tper_id`, `Tper_desperfil`, `Tper_estado`) VALUES
(1, 'Administrador', 'A'),
(3, 'Usuario', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tipo_tratamiento`
--

CREATE TABLE `tbl_tipo_tratamiento` (
  `tipo_id` int(11) NOT NULL,
  `tipo_desc` varchar(200) DEFAULT NULL,
  `tipo_estado` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_tipo_tratamiento`
--

INSERT INTO `tbl_tipo_tratamiento` (`tipo_id`, `tipo_desc`, `tipo_estado`) VALUES
(3, 'CIRUGIA', 'A'),
(4, 'QUIMIOTERAPIA', 'A'),
(5, 'REHABILITACION FISICA', 'A'),
(6, 'TERAPIA HORMONAL', 'A'),
(7, 'RADIOTERAPIA', 'A'),
(8, 'NINGUNA', 'A'),
(9, 'REPOSO', 'A'),
(10, 'TERAPIA DIRIGIDA', 'A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_tratamiento`
--

CREATE TABLE `tbl_tratamiento` (
  `trat_id` int(11) NOT NULL,
  `cit_id` int(11) DEFAULT NULL,
  `tipo_id` int(11) DEFAULT NULL,
  `trat_medicamento` varchar(200) DEFAULT NULL,
  `trat_nota` varchar(200) DEFAULT NULL,
  `trat_costo` float DEFAULT NULL,
  `trat_estado_pago` varchar(30) DEFAULT NULL,
  `trat_estado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_tratamiento`
--

INSERT INTO `tbl_tratamiento` (`trat_id`, `cit_id`, `tipo_id`, `trat_medicamento`, `trat_nota`, `trat_costo`, `trat_estado_pago`, `trat_estado`) VALUES
(2, 5, 8, 'Loratadina', '3 veces al dia', 6, 'Pagado', 'Cancelado'),
(3, 7, 9, 'Paracetamol', 'Cada 8 Horas', 10, 'Pagado', 'Aplicado'),
(4, 8, 9, 'Flucetrin', 'Cada 8 horas', 12, 'Pagado', 'Aplicado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_usuario`
--

CREATE TABLE `tbl_usuario` (
  `usu_id` int(11) NOT NULL,
  `per_id` int(11) DEFAULT NULL,
  `usu_correo` varchar(200) DEFAULT NULL,
  `usu_nomlogin` varchar(50) DEFAULT NULL,
  `usu_pass` varchar(50) DEFAULT NULL,
  `Tper_id` int(11) NOT NULL,
  `usu_estado` varchar(10) DEFAULT NULL,
  `usu_fecha` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tbl_usuario`
--

INSERT INTO `tbl_usuario` (`usu_id`, `per_id`, `usu_correo`, `usu_nomlogin`, `usu_pass`, `Tper_id`, `usu_estado`, `usu_fecha`) VALUES
(13, 1, 'davidnava1998efrain@outlook.com', 'DNavarrete', 'RDJCRWV4bGZOY2ZlQVRLK2tBQWdFZz09', 1, 'A', '2020-06-11'),
(14, 2, 'campananaranjo@hotmail.com', 'LCampana', 'Z2wwLzZJYWZZQU5XSmJUZ2tISVlFUT09', 3, 'A', '2020-06-11');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_centro_medico`
--
ALTER TABLE `tbl_centro_medico`
  ADD PRIMARY KEY (`cent_id`);

--
-- Indices de la tabla `tbl_cita`
--
ALTER TABLE `tbl_cita`
  ADD PRIMARY KEY (`cit_id`),
  ADD KEY `med_id` (`med_id`),
  ADD KEY `cent_id` (`cent_id`),
  ADD KEY `pac_id` (`pac_id`);

--
-- Indices de la tabla `tbl_especialidad`
--
ALTER TABLE `tbl_especialidad`
  ADD PRIMARY KEY (`esp_id`);

--
-- Indices de la tabla `tbl_horario`
--
ALTER TABLE `tbl_horario`
  ADD PRIMARY KEY (`hor_id`);

--
-- Indices de la tabla `tbl_medico`
--
ALTER TABLE `tbl_medico`
  ADD PRIMARY KEY (`med_id`),
  ADD KEY `per_id` (`per_id`),
  ADD KEY `hor_id` (`hor_id`),
  ADD KEY `esp_id` (`esp_id`),
  ADD KEY `cent_id` (`cent_id`);

--
-- Indices de la tabla `tbl_paciente`
--
ALTER TABLE `tbl_paciente`
  ADD PRIMARY KEY (`pac_id`),
  ADD KEY `per_id` (`per_id`);

--
-- Indices de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  ADD PRIMARY KEY (`per_id`);

--
-- Indices de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  ADD PRIMARY KEY (`Tper_id`);

--
-- Indices de la tabla `tbl_tipo_tratamiento`
--
ALTER TABLE `tbl_tipo_tratamiento`
  ADD PRIMARY KEY (`tipo_id`);

--
-- Indices de la tabla `tbl_tratamiento`
--
ALTER TABLE `tbl_tratamiento`
  ADD PRIMARY KEY (`trat_id`),
  ADD KEY `cit_id` (`cit_id`),
  ADD KEY `tipo_id` (`tipo_id`);

--
-- Indices de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD PRIMARY KEY (`usu_id`),
  ADD KEY `per_id` (`per_id`),
  ADD KEY `Tper_id` (`Tper_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_centro_medico`
--
ALTER TABLE `tbl_centro_medico`
  MODIFY `cent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbl_cita`
--
ALTER TABLE `tbl_cita`
  MODIFY `cit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tbl_especialidad`
--
ALTER TABLE `tbl_especialidad`
  MODIFY `esp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tbl_horario`
--
ALTER TABLE `tbl_horario`
  MODIFY `hor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `tbl_medico`
--
ALTER TABLE `tbl_medico`
  MODIFY `med_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tbl_paciente`
--
ALTER TABLE `tbl_paciente`
  MODIFY `pac_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tbl_persona`
--
ALTER TABLE `tbl_persona`
  MODIFY `per_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `tbl_tipoperfil`
--
ALTER TABLE `tbl_tipoperfil`
  MODIFY `Tper_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `tbl_tipo_tratamiento`
--
ALTER TABLE `tbl_tipo_tratamiento`
  MODIFY `tipo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `tbl_tratamiento`
--
ALTER TABLE `tbl_tratamiento`
  MODIFY `trat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  MODIFY `usu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `tbl_cita`
--
ALTER TABLE `tbl_cita`
  ADD CONSTRAINT `tbl_cita_ibfk_1` FOREIGN KEY (`med_id`) REFERENCES `tbl_medico` (`med_id`),
  ADD CONSTRAINT `tbl_cita_ibfk_2` FOREIGN KEY (`cent_id`) REFERENCES `tbl_centro_medico` (`cent_id`),
  ADD CONSTRAINT `tbl_cita_ibfk_3` FOREIGN KEY (`pac_id`) REFERENCES `tbl_paciente` (`pac_id`);

--
-- Filtros para la tabla `tbl_medico`
--
ALTER TABLE `tbl_medico`
  ADD CONSTRAINT `tbl_medico_ibfk_1` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_medico_ibfk_2` FOREIGN KEY (`hor_id`) REFERENCES `tbl_horario` (`hor_id`),
  ADD CONSTRAINT `tbl_medico_ibfk_3` FOREIGN KEY (`esp_id`) REFERENCES `tbl_especialidad` (`esp_id`),
  ADD CONSTRAINT `tbl_medico_ibfk_4` FOREIGN KEY (`cent_id`) REFERENCES `tbl_centro_medico` (`cent_id`);

--
-- Filtros para la tabla `tbl_paciente`
--
ALTER TABLE `tbl_paciente`
  ADD CONSTRAINT `tbl_paciente_ibfk_1` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`);

--
-- Filtros para la tabla `tbl_tratamiento`
--
ALTER TABLE `tbl_tratamiento`
  ADD CONSTRAINT `tbl_tratamiento_ibfk_1` FOREIGN KEY (`cit_id`) REFERENCES `tbl_cita` (`cit_id`),
  ADD CONSTRAINT `tbl_tratamiento_ibfk_2` FOREIGN KEY (`tipo_id`) REFERENCES `tbl_tipo_tratamiento` (`tipo_id`);

--
-- Filtros para la tabla `tbl_usuario`
--
ALTER TABLE `tbl_usuario`
  ADD CONSTRAINT `tbl_usuario_ibfk_1` FOREIGN KEY (`per_id`) REFERENCES `tbl_persona` (`per_id`),
  ADD CONSTRAINT `tbl_usuario_ibfk_2` FOREIGN KEY (`Tper_id`) REFERENCES `tbl_tipoperfil` (`Tper_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
